import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { useAppStore } from "@/lib/app-store";
import { t } from "@/lib/i18n";
import { sendChat } from "@/lib/send-chat";
import { performHaptic } from "@/lib/haptics";

type SpeechRec = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
};

type RecCtor = new () => SpeechRec;

export function VoiceMode() {
  const open = useAppStore((s) => s.ui.voiceOpen);
  const locale = useAppStore((s) => s.settings.locale);
  const auto = useAppStore((s) => s.settings.autoSubmitVoice);
  const lang = useAppStore((s) => s.settings.voiceLanguage);
  const haptics = useAppStore((s) => s.settings.haptics);
  const [level, setLevel] = useState(0.12);
  const [transcript, setTranscript] = useState("");
  const recRef = useRef<SpeechRec | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const raf = useRef(0);

  useEffect(() => {
    if (!open) return;
    setTranscript("");
    performHaptic("open", haptics);

    const SR = (window as unknown as { SpeechRecognition?: RecCtor; webkitSpeechRecognition?: RecCtor })
      .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: RecCtor }).webkitSpeechRecognition;
    if (SR) {
      const rec = new SR();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = locale === "bn" ? "bn-BD" : lang || "en-US";
      rec.onresult = (ev) => {
        let text = "";
        for (let i = 0; i < ev.results.length; i++) {
          text += ev.results[i]![0]!.transcript;
        }
        setTranscript(text.trim());
      };
      rec.start();
      recRef.current = rec;
    }

    let stream: MediaStream | null = null;
    void (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const ctx = new AudioContext();
        ctxRef.current = ctx;
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(analyser);
        const data = new Uint8Array(analyser.frequencyBinCount);
        const loop = () => {
          analyser.getByteTimeDomainData(data);
          let sum = 0;
          for (const n of data) {
            const v = (n - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / data.length);
          setLevel(0.12 + Math.min(0.7, rms * 3));
          raf.current = requestAnimationFrame(loop);
        };
        loop();
      } catch {
        const loop = () => {
          setLevel(0.18 + Math.sin(Date.now() / 420) * 0.08);
          raf.current = requestAnimationFrame(loop);
        };
        loop();
      }
    })();

    return () => {
      recRef.current?.stop();
      recRef.current = null;
      cancelAnimationFrame(raf.current);
      void ctxRef.current?.close();
      ctxRef.current = null;
      stream?.getTracks().forEach((tr) => tr.stop());
    };
  }, [open, locale, lang, haptics]);

  async function close(submit: boolean) {
    recRef.current?.stop();
    useAppStore.getState().setVoiceOpen(false);
    if (submit && transcript) {
      await sendChat({ content: transcript });
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-bg text-fg">
      <div className="flex justify-end px-4 pt-[max(16px,env(safe-area-inset-top))]">
        <button
          type="button"
          aria-label={t(locale, "close")}
          className="flex size-11 items-center justify-center rounded-full text-muted hover:bg-elevated hover:text-fg"
          onClick={() => void close(false)}
        >
          <X className="size-5" />
        </button>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center gap-8 px-8">
        <button
          type="button"
          onClick={() => void close(auto)}
          className="relative flex size-44 items-center justify-center"
          aria-label={t(locale, "voiceTap")}
        >
          <span
            className="orb absolute rounded-full"
            style={{
              width: `${140 + level * 90}px`,
              height: `${140 + level * 90}px`,
              opacity: 0.95,
              transform: `scale(${0.92 + level * 0.2})`,
              transition: "transform 80ms linear, width 80ms linear, height 80ms linear",
            }}
          />
        </button>
        <div className="text-center">
          <p className="text-sm font-medium text-accent">{t(locale, "voiceListen")}</p>
          <p className="mt-2 min-h-12 max-w-md text-base text-fg">
            {transcript || t(locale, "voiceSpeak")}
          </p>
        </div>
      </div>
      <p className="pb-[max(24px,env(safe-area-inset-bottom))] text-center text-xs text-muted">
        {t(locale, "voiceTap")}
      </p>
    </div>
  );
}

