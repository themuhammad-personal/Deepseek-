import { useEffect } from "react";
import { BottomSheet } from "./ui/bottom-sheet";
import { useAppStore } from "@/lib/app-store";
import { pingServer } from "@/lib/mcp-presets";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function McpDashboard() {
  const open = useAppStore((s) => s.ui.mcpOpen);
  const mcp = useAppStore((s) => s.mcp);
  const locale = useAppStore((s) => s.settings.locale);

  useEffect(() => {
    let alive = true;
    async function tick() {
      const list = useAppStore.getState().mcp;
      await Promise.all(
        list.map(async (s) => {
          useAppStore.getState().setMcpStatus(s.id, { status: "checking" });
          const r = await pingServer(s);
          if (!alive) return;
          useAppStore.getState().setMcpStatus(s.id, {
            status: r.status,
            latency: r.latency,
            lastPingMs: Date.now(),
          });
        }),
      );
    }
    void tick();
    const id = window.setInterval(() => void tick(), 14000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, []);

  return (
    <BottomSheet
      open={open}
      onOpenChange={(v) => useAppStore.getState().setMcpOpen(v)}
      title={t(locale, "mcpTitle")}
    >
      <p className="pb-3 text-sm text-muted">{t(locale, "mcpHint")}</p>
      <div className="space-y-2 pb-4">
        {mcp.map((s) => (
          <div
            key={s.id}
            className="flex items-start gap-3 rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]"
          >
            <span
              className={cn(
                "mt-1.5 size-2 shrink-0 rounded-full",
                s.status === "online" && "bg-ok",
                s.status === "offline" && "bg-danger",
                s.status === "checking" && "bg-warn",
              )}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="truncate text-sm font-medium">{s.name}</p>
                <span className="text-[11px] uppercase tracking-wide text-faint">
                  {t(locale, s.status)}
                  {s.latency != null && s.status === "online" ? ` · ${s.latency}ms` : ""}
                </span>
              </div>
              <p className="text-xs text-muted">{s.description}</p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={s.enabled}
              onClick={() => useAppStore.getState().toggleMcp(s.id)}
              className={cn(
                "relative h-7 w-12 shrink-0 rounded-full transition-colors duration-200",
                s.enabled ? "bg-accent" : "bg-surface shadow-[var(--shadow-border)]",
              )}
            >
              <span
                className={cn(
                  "absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-200",
                  s.enabled ? "translate-x-5" : "translate-x-0.5",
                )}
              />
            </button>
          </div>
        ))}
      </div>
    </BottomSheet>
  );
}
