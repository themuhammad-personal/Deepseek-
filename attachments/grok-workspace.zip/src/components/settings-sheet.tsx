import type { ReactNode } from "react";
import { BottomSheet } from "./ui/bottom-sheet";
import { useAppStore } from "@/lib/app-store";
import { t } from "@/lib/i18n";
import { ragClear, ragList } from "@/lib/rag";
import type { AccentPref, Locale, ThemePref } from "@/lib/types";
import { cn } from "@/lib/utils";

function Row({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        {hint ? <p className="text-xs text-muted">{hint}</p> : null}
      </div>
      {children}
    </div>
  );
}

function Segment<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-[var(--radius-sm)] bg-elevated p-1 shadow-[var(--shadow-border)]">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={cn(
            "h-8 rounded-[6px] px-2.5 text-xs font-medium",
            value === o.id ? "bg-surface text-fg" : "text-muted",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={cn(
        "relative h-7 w-12 rounded-full transition-colors duration-200",
        on ? "bg-accent" : "bg-elevated shadow-[var(--shadow-border)]",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-200",
          on ? "translate-x-5" : "translate-x-0.5",
        )}
      />
    </button>
  );
}

export function SettingsSheet() {
  const open = useAppStore((s) => s.ui.settingsOpen);
  const settings = useAppStore((s) => s.settings);
  const ragCount = useAppStore((s) => s.ui.ragCount);
  const locale = settings.locale;
  const patch = useAppStore.getState().patchSettings;

  return (
    <BottomSheet
      open={open}
      onOpenChange={(v) => useAppStore.getState().setSettingsOpen(v)}
      title={t(locale, "settings")}
    >
      <section className="mb-4 rounded-[var(--radius-lg)] bg-elevated px-4 shadow-[var(--shadow-border)]">
        <h3 className="pt-3 text-[11px] font-medium uppercase tracking-[0.08em] text-faint">
          {t(locale, "appearance")}
        </h3>
        <Row label={t(locale, "theme")}>
          <Segment<ThemePref>
            value={settings.theme}
            onChange={(theme) => patch({ theme })}
            options={[
              { id: "oled", label: t(locale, "oled") },
              { id: "light", label: t(locale, "light") },
              { id: "system", label: t(locale, "system") },
            ]}
          />
        </Row>
        <Row label={t(locale, "accent")}>
          <Segment<AccentPref>
            value={settings.accent}
            onChange={(accent) => patch({ accent })}
            options={[
              { id: "ice", label: "Ice" },
              { id: "ocean", label: "Ocean" },
              { id: "sage", label: "Sage" },
              { id: "graphite", label: "Ink" },
            ]}
          />
        </Row>
        <Row label={t(locale, "language")}>
          <Segment<Locale>
            value={settings.locale}
            onChange={(l) => useAppStore.getState().setLocale(l)}
            options={[
              { id: "en", label: "EN" },
              { id: "bn", label: "বাংলা" },
            ]}
          />
        </Row>
      </section>

      <section className="mb-4 rounded-[var(--radius-lg)] bg-elevated px-4 shadow-[var(--shadow-border)]">
        <h3 className="pt-3 text-[11px] font-medium uppercase tracking-[0.08em] text-faint">
          {t(locale, "chat")}
        </h3>
        <Row label={t(locale, "timestamps")}>
          <Toggle on={settings.showTimestamps} onChange={(showTimestamps) => patch({ showTimestamps })} />
        </Row>
        <Row label={t(locale, "haptics")}>
          <Toggle on={settings.haptics} onChange={(haptics) => patch({ haptics })} />
        </Row>
        <Row label={t(locale, "voiceAuto")}>
          <Toggle on={settings.autoSubmitVoice} onChange={(autoSubmitVoice) => patch({ autoSubmitVoice })} />
        </Row>
        <Row label={t(locale, "collapse")}>
          <Toggle on={settings.collapseLong} onChange={(collapseLong) => patch({ collapseLong })} />
        </Row>
      </section>

      <section className="mb-4 rounded-[var(--radius-lg)] bg-elevated px-4 pb-3 shadow-[var(--shadow-border)]">
        <h3 className="pt-3 text-[11px] font-medium uppercase tracking-[0.08em] text-faint">
          {t(locale, "rag")}
        </h3>
        <Row label={t(locale, "indexedFiles")} hint={t(locale, "deepCodeHint")}>
          <span className="tabular-nums text-sm">{ragCount}</span>
        </Row>
        <Row label={t(locale, "ragChunks")}>
          <Segment<string>
            value={String(settings.ragChunks)}
            onChange={(v) => patch({ ragChunks: Number(v) })}
            options={[
              { id: "3", label: "3" },
              { id: "5", label: "5" },
              { id: "8", label: "8" },
            ]}
          />
        </Row>
        <button
          type="button"
          className="mb-3 h-10 w-full rounded-[var(--radius-sm)] bg-surface text-sm text-danger"
          onClick={() => {
            void ragClear().then(() => {
              useAppStore.getState().setRagCount(0);
            });
          }}
        >
          {t(locale, "clearIndex")}
        </button>
      </section>
    </BottomSheet>
  );
}

export function refreshRagCount() {
  void ragList().then((d) => useAppStore.getState().setRagCount(d.length));
}
