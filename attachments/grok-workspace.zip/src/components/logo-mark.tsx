export function LogoMark({ className = "size-8" }: { className?: string }) {
  return (
    <img
      src="/logo.png"
      alt=""
      className={`${className} rounded-[var(--radius-sm)] object-cover`}
    />
  );
}
