import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  AccentPref,
  Account,
  Attachment,
  CharacterEntry,
  Chat,
  ChatMode,
  Locale,
  McpServer,
  MemoryEntry,
  Message,
  PromptEntry,
  QueuedItem,
  Settings,
  SkillEntry,
  ThemePref,
} from "./types";
import { uid } from "./utils";
import { defaultMcpServers } from "./mcp-presets";
import { titleFromPrompt } from "./group-chats";

const defaultSettings: Settings = {
  theme: "oled",
  accent: "ice",
  locale: "en",
  showTimestamps: false,
  haptics: true,
  autoSubmitVoice: true,
  voiceLanguage: "en-US",
  collapseLong: true,
  ragChunks: 5,
  voiceMode: false,
  syncLocale: true,
  preferredLang: "",
  disableSystemPrompt: false,
  disableMemory: false,
  injectSystemDateTime: true,
  skipDeletionConfirmation: false,
  systemPromptInjectionFrequency: "first",
  systemPromptInjectionInterval: 3,
  tokenPriceDisplay: false,
  oledDarkMode: true,
  disableTipBox: false,
  processGitignoreOnUpload: true,
  loadAllHistoryOnSession: false,
  projectRagEnabled: true,
  autoDownloadFiles: false,
  autoDownloadLongWorkZip: false,
  githubToken: "",
  searchProviders: ["ddg-lite", "ddg-html", "bing"],
  deepResearchDeepFetch: 1,
  deepResearchContextGuardEnabled: true,
  deepResearchContextLimitTokens: 128000,
  mcpInlineMaxChars: 8000,
  htmlToMarkdownMaxDepth: 400,
  maxChatSessions: 500,
  vadSilenceTimeout: 1500,
  customCSS: "",
  activeSystemPromptId: "default",
};

type UiState = {
  sidebarOpen: boolean;
  attachOpen: boolean;
  settingsOpen: boolean;
  mcpOpen: boolean;
  voiceOpen: boolean;
  queueOpen: boolean;
  artifactId: string | null;
  streamingId: string | null;
  mode: ChatMode;
  webSearch: boolean;
  online: boolean;
  hydrated: boolean;
  ragCount: number;
  loginError: string;
  loginBusy: boolean;
};

type AppState = {
  account: Account | null;
  chats: Chat[];
  activeChatId: string | null;
  settings: Settings;
  mcp: McpServer[];
  queue: QueuedItem[];
  prompts: PromptEntry[];
  memories: MemoryEntry[];
  skills: SkillEntry[];
  characters: CharacterEntry[];
  ui: UiState;
};

type Actions = {
  hydrateUi: () => void;
  setOnline: (v: boolean) => void;
  setLocale: (l: Locale) => void;
  setTheme: (t: ThemePref) => void;
  setAccent: (a: AccentPref) => void;
  patchSettings: (p: Partial<Settings>) => void;
  setAccount: (a: Account | null) => void;
  setSidebar: (v: boolean) => void;
  setAttachOpen: (v: boolean) => void;
  setSettingsOpen: (v: boolean) => void;
  setMcpOpen: (v: boolean) => void;
  setVoiceOpen: (v: boolean) => void;
  setQueueOpen: (v: boolean) => void;
  setMode: (m: ChatMode) => void;
  setWebSearch: (v: boolean) => void;
  setRagCount: (n: number) => void;
  setArtifact: (id: string | null) => void;
  setLoginError: (s: string) => void;
  setLoginBusy: (v: boolean) => void;
  newChat: () => string;
  selectChat: (id: string) => void;
  renameChat: (id: string, title: string) => void;
  deleteChat: (id: string) => void;
  pinChat: (id: string) => void;
  bindDsSession: (chatId: string, dsSessionId: string) => void;
  appendMessage: (chatId: string, msg: Message) => void;
  patchMessage: (chatId: string, msgId: string, patch: Partial<Message>) => void;
  setStreaming: (id: string | null) => void;
  enqueue: (item: Omit<QueuedItem, "id" | "createdAt">) => void;
  dequeue: (id: string) => void;
  clearQueue: () => void;
  toggleMcp: (id: string) => void;
  setMcpStatus: (id: string, patch: Partial<McpServer>) => void;
  upsertPrompt: (p: PromptEntry) => void;
  deletePrompt: (id: string) => void;
  upsertMemory: (m: MemoryEntry) => void;
  deleteMemory: (id: string) => void;
  upsertSkill: (s: SkillEntry) => void;
  deleteSkill: (id: string) => void;
  upsertCharacter: (c: CharacterEntry) => void;
  deleteCharacter: (id: string) => void;
  ensureChat: (prompt: string) => string;
};

const emptyUi = (): UiState => ({
  sidebarOpen: false,
  attachOpen: false,
  settingsOpen: false,
  mcpOpen: false,
  voiceOpen: false,
  queueOpen: false,
  artifactId: null,
  streamingId: null,
  mode: "instant",
  webSearch: false,
  online: true,
  hydrated: false,
  ragCount: 0,
  loginError: "",
  loginBusy: false,
});

export const useAppStore = create<AppState & Actions>()(
  persist(
    (set, get) => ({
      account: null,
      chats: [],
      activeChatId: null,
      settings: defaultSettings,
      mcp: defaultMcpServers(),
      queue: [],
      prompts: [],
      memories: [],
      skills: [],
      characters: [],
      ui: emptyUi(),
      hydrateUi: () => set((s) => ({ ui: { ...s.ui, hydrated: true } })),
      setOnline: (v) => set((s) => ({ ui: { ...s.ui, online: v } })),
      setLocale: (locale) => set((s) => ({ settings: { ...s.settings, locale } })),
      setTheme: (theme) => set((s) => ({ settings: { ...s.settings, theme } })),
      setAccent: (accent) => set((s) => ({ settings: { ...s.settings, accent } })),
      patchSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      setAccount: (account) => set({ account }),
      setSidebar: (sidebarOpen) => set((s) => ({ ui: { ...s.ui, sidebarOpen } })),
      setAttachOpen: (attachOpen) => set((s) => ({ ui: { ...s.ui, attachOpen } })),
      setSettingsOpen: (settingsOpen) => set((s) => ({ ui: { ...s.ui, settingsOpen } })),
      setMcpOpen: (mcpOpen) => set((s) => ({ ui: { ...s.ui, mcpOpen } })),
      setVoiceOpen: (voiceOpen) => set((s) => ({ ui: { ...s.ui, voiceOpen } })),
      setQueueOpen: (queueOpen) => set((s) => ({ ui: { ...s.ui, queueOpen } })),
      setMode: (mode) =>
        set((s) => ({
          ui: {
            ...s.ui,
            mode,
            webSearch: mode === "research" ? true : s.ui.webSearch,
          },
        })),
      setWebSearch: (webSearch) => set((s) => ({ ui: { ...s.ui, webSearch } })),
      setRagCount: (ragCount) => set((s) => ({ ui: { ...s.ui, ragCount } })),
      setArtifact: (artifactId) => set((s) => ({ ui: { ...s.ui, artifactId } })),
      setLoginError: (loginError) => set((s) => ({ ui: { ...s.ui, loginError } })),
      setLoginBusy: (loginBusy) => set((s) => ({ ui: { ...s.ui, loginBusy } })),
      newChat: () => {
        const chat: Chat = {
          id: uid("chat"),
          title: "New chat",
          createdAt: Date.now(),
          updatedAt: Date.now(),
          pinned: false,
          messages: [],
        };
        set((s) => ({
          chats: [chat, ...s.chats].slice(0, s.settings.maxChatSessions),
          activeChatId: chat.id,
          ui: { ...s.ui, sidebarOpen: false, artifactId: null },
        }));
        return chat.id;
      },
      selectChat: (id) =>
        set((s) => ({
          activeChatId: id,
          ui: { ...s.ui, sidebarOpen: false, artifactId: null },
        })),
      renameChat: (id, title) =>
        set((s) => ({
          chats: s.chats.map((c) => (c.id === id ? { ...c, title } : c)),
        })),
      deleteChat: (id) =>
        set((s) => {
          const chats = s.chats.filter((c) => c.id !== id);
          const activeChatId =
            s.activeChatId === id ? (chats[0]?.id ?? null) : s.activeChatId;
          return { chats, activeChatId };
        }),
      pinChat: (id) =>
        set((s) => ({
          chats: s.chats.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)),
        })),
      bindDsSession: (chatId, dsSessionId) =>
        set((s) => ({
          chats: s.chats.map((c) => (c.id === chatId ? { ...c, dsSessionId } : c)),
        })),
      appendMessage: (chatId, msg) =>
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId
              ? { ...c, messages: [...c.messages, msg], updatedAt: Date.now() }
              : c,
          ),
        })),
      patchMessage: (chatId, msgId, patch) =>
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id !== chatId
              ? c
              : {
                  ...c,
                  updatedAt: Date.now(),
                  messages: c.messages.map((m) => (m.id === msgId ? { ...m, ...patch } : m)),
                },
          ),
        })),
      setStreaming: (streamingId) => set((s) => ({ ui: { ...s.ui, streamingId } })),
      enqueue: (item) =>
        set((s) => ({
          queue: [...s.queue, { ...item, id: uid("q"), createdAt: Date.now() }],
        })),
      dequeue: (id) => set((s) => ({ queue: s.queue.filter((q) => q.id !== id) })),
      clearQueue: () => set({ queue: [] }),
      toggleMcp: (id) =>
        set((s) => ({
          mcp: s.mcp.map((m) => (m.id === id ? { ...m, enabled: !m.enabled } : m)),
        })),
      setMcpStatus: (id, patch) =>
        set((s) => ({
          mcp: s.mcp.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        })),
      upsertPrompt: (p) =>
        set((s) => ({
          prompts: s.prompts.some((x) => x.id === p.id)
            ? s.prompts.map((x) => (x.id === p.id ? p : x))
            : [...s.prompts, p],
        })),
      deletePrompt: (id) => set((s) => ({ prompts: s.prompts.filter((p) => p.id !== id) })),
      upsertMemory: (m) =>
        set((s) => ({
          memories: s.memories.some((x) => x.id === m.id)
            ? s.memories.map((x) => (x.id === m.id ? m : x))
            : [...s.memories, m],
        })),
      deleteMemory: (id) => set((s) => ({ memories: s.memories.filter((m) => m.id !== id) })),
      upsertSkill: (sk) =>
        set((s) => ({
          skills: s.skills.some((x) => x.id === sk.id)
            ? s.skills.map((x) => (x.id === sk.id ? sk : x))
            : [...s.skills, sk],
        })),
      deleteSkill: (id) => set((s) => ({ skills: s.skills.filter((s0) => s0.id !== id) })),
      upsertCharacter: (c) =>
        set((s) => ({
          characters: s.characters.map((x) => ({ ...x, active: x.id === c.id ? c.active : false })).some((x) => x.id === c.id)
            ? s.characters.map((x) =>
                x.id === c.id ? c : { ...x, active: c.active ? false : x.active },
              )
            : [...s.characters.map((x) => ({ ...x, active: c.active ? false : x.active })), c],
        })),
      deleteCharacter: (id) =>
        set((s) => ({ characters: s.characters.filter((c) => c.id !== id) })),
      ensureChat: (prompt) => {
        const s = get();
        const active = s.chats.find((c) => c.id === s.activeChatId);
        if (active && active.messages.length === 0) {
          if (active.title === "New chat") {
            get().renameChat(active.id, titleFromPrompt(prompt));
          }
          return active.id;
        }
        const id = get().newChat();
        get().renameChat(id, titleFromPrompt(prompt));
        return id;
      },
    }),
    {
      name: "super-deepseek-v2",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        account: s.account,
        chats: s.chats,
        activeChatId: s.activeChatId,
        settings: s.settings,
        mcp: s.mcp.map(({ status: _st, latency: _l, lastPingMs: _p, ...rest }) => ({
          ...rest,
          status: "checking" as const,
        })),
        queue: s.queue,
        prompts: s.prompts,
        memories: s.memories,
        skills: s.skills,
        characters: s.characters,
      }),
    },
  ),
);

export function useActiveChat(): Chat | undefined {
  return useAppStore((s) => s.chats.find((c) => c.id === s.activeChatId));
}

export function activeArtifact(chat: Chat | undefined, artifactId: string | null) {
  if (!chat || !artifactId) return null;
  for (const m of chat.messages) {
    const hit = m.artifacts?.find((a) => a.id === artifactId);
    if (hit) return hit;
  }
  return null;
}

export function emptyMessage(partial: Partial<Message> & Pick<Message, "role" | "content">): Message {
  return {
    id: uid("msg"),
    createdAt: Date.now(),
    ...partial,
  };
}

export function draftUser(content: string, attachments: Attachment[]): Message {
  return emptyMessage({ role: "user", content, attachments });
}
