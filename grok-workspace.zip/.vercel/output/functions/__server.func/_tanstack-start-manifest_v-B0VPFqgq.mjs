//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B0VPFqgq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/chat",
			"/api/import",
			"/api/ds/complete",
			"/api/ds/login",
			"/api/ds/me",
			"/api/ds/session"
		],
		preloads: ["/assets/index-BAS-x40D.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BAS-x40D.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-rRu40vi2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
