import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as Copy, D as Camera, E as Check, O as Atom, S as FileText, T as ChevronDown, _ as Library, a as Trash2, b as Github, c as SquareTerminal, d as Puzzle, f as Plus, g as LogOut, h as Menu, k as ArrowUp, l as Settings, m as Pin, n as X, o as Telescope, p as Play, r as WifiOff, s as Square, t as Zap, u as Search, v as Image$1, w as Command, x as Folder, y as Globe } from "../_libs/lucide-react.mjs";
import { n as buildSystemPrompt } from "./router-Bwp3eDp3.mjs";
import { n as nn, r as qt, t as Qt } from "../_libs/react-resizable-panels.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as isToday, r as differenceInCalendarDays, t as isYesterday } from "../_libs/date-fns.mjs";
import { t as gn } from "../_libs/marked.mjs";
import { a as sql, c as json, d as python, f as typescript, i as rust, l as css, m as core_default, n as java, o as markdown, p as javascript, r as go, s as bash, t as kotlin, u as xml } from "../_libs/highlight.js.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BfDhy9oT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LogoMark({ className = "size-8" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "64",
				height: "64",
				rx: "16",
				fill: "var(--color-elevated)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "18",
				fill: "none",
				stroke: "var(--color-accent)",
				strokeWidth: "1.6",
				opacity: "0.45"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "10",
				fill: "var(--color-accent)",
				opacity: "0.22"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "4.5",
				fill: "var(--color-accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "20",
				r: "2",
				fill: "var(--color-accent)",
				opacity: "0.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "42",
				r: "1.6",
				fill: "var(--color-fg)",
				opacity: "0.55"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 34c6 8 22 8 28 0",
				fill: "none",
				stroke: "var(--color-accent)",
				strokeWidth: "1.4",
				strokeLinecap: "round",
				opacity: "0.7"
			})
		]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function formatTime(ts) {
	return new Date(ts).toLocaleTimeString(void 0, {
		hour: "numeric",
		minute: "2-digit"
	});
}
var MCP_PRESETS = [
	{
		id: "web",
		name: "Web Content Fetcher",
		description: "Reads full text and markdown from any URL you share.",
		endpoint: "builtin://web",
		builtin: true
	},
	{
		id: "search",
		name: "Live Web Search",
		description: "Real-time search and news discovery for Deep Research.",
		endpoint: "builtin://search",
		builtin: true
	},
	{
		id: "weather",
		name: "Weather & Time",
		description: "Worldwide forecasts via Open-Meteo and local clocks.",
		endpoint: "https://api.open-meteo.com/v1/forecast?latitude=23.81&longitude=90.41&current=temperature_2m",
		builtin: true
	},
	{
		id: "github",
		name: "GitHub Explorer",
		description: "Inspect public repositories, files, and commit history.",
		endpoint: "https://api.github.com",
		builtin: true
	},
	{
		id: "termux",
		name: "Local Termux Bridge",
		description: "Connects to a Termux SSE server on the device LAN.",
		endpoint: "http://127.0.0.1:18080/sse",
		builtin: false
	}
];
function defaultMcpServers() {
	return MCP_PRESETS.map((p) => ({
		...p,
		enabled: p.id !== "termux",
		status: "checking"
	}));
}
async function pingServer(server) {
	if (server.endpoint.startsWith("builtin://")) return {
		status: "online",
		latency: 4
	};
	const started = performance.now();
	try {
		const ctrl = new AbortController();
		const t = window.setTimeout(() => ctrl.abort(), 3500);
		const res = await fetch(server.endpoint, {
			method: "GET",
			signal: ctrl.signal,
			mode: "cors"
		});
		window.clearTimeout(t);
		const latency = Math.round(performance.now() - started);
		return {
			status: res.ok || res.status === 404 ? "online" : "offline",
			latency
		};
	} catch {
		return {
			status: "offline",
			latency: Math.round(performance.now() - started)
		};
	}
}
function groupChats(chats) {
	const buckets = {
		pinned: [],
		today: [],
		yesterday: [],
		week: [],
		older: []
	};
	const sorted = [...chats].sort((a, b) => b.updatedAt - a.updatedAt);
	for (const c of sorted) {
		if (c.pinned) {
			buckets.pinned.push(c);
			continue;
		}
		const d = new Date(c.updatedAt);
		if (isToday(d)) buckets.today.push(c);
		else if (isYesterday(d)) buckets.yesterday.push(c);
		else if (differenceInCalendarDays(/* @__PURE__ */ new Date(), d) <= 7) buckets.week.push(c);
		else buckets.older.push(c);
	}
	return [
		"pinned",
		"today",
		"yesterday",
		"week",
		"older"
	].filter((k) => buckets[k].length).map((key) => ({
		key,
		items: buckets[key]
	}));
}
function titleFromPrompt(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (!clean) return "New chat";
	return clean.length > 42 ? `${clean.slice(0, 42)}…` : clean;
}
var defaultSettings = {
	theme: "oled",
	accent: "ice",
	locale: "en",
	showTimestamps: false,
	haptics: true,
	collapseLong: true,
	ragChunks: 5,
	syncLocale: true,
	preferredLang: "",
	disableSystemPrompt: false,
	disableMemory: false,
	injectSystemDateTime: true,
	skipDeletionConfirmation: false,
	systemPromptInjectionFrequency: "first",
	systemPromptInjectionInterval: 3,
	tokenPriceDisplay: false,
	oledDarkMode: true,
	disableTipBox: false,
	processGitignoreOnUpload: true,
	loadAllHistoryOnSession: false,
	projectRagEnabled: true,
	autoDownloadFiles: false,
	autoDownloadLongWorkZip: false,
	githubToken: "",
	searchProviders: [
		"ddg-lite",
		"ddg-html",
		"bing"
	],
	deepResearchDeepFetch: 1,
	deepResearchContextGuardEnabled: true,
	deepResearchContextLimitTokens: 128e3,
	deepResearchContextStopPercent: 70,
	mcpInlineMaxChars: 8e3,
	htmlToMarkdownMaxDepth: 400,
	maxChatSessions: 500,
	customCSS: "",
	activeSystemPromptId: "default",
	systemPromptMultiMode: false
};
var emptyUi = () => ({
	sidebarOpen: false,
	attachOpen: false,
	settingsOpen: false,
	mcpOpen: false,
	queueOpen: false,
	libraryOpen: false,
	libraryTab: "prompts",
	commandsOpen: false,
	artifactId: null,
	streamingId: null,
	mode: "instant",
	webSearch: false,
	online: true,
	hydrated: false,
	ragCount: 0,
	loginError: "",
	loginBusy: false
});
var useAppStore = create()(persist((set, get) => ({
	account: null,
	chats: [],
	activeChatId: null,
	settings: defaultSettings,
	mcp: defaultMcpServers(),
	queue: [],
	prompts: [],
	memories: [],
	skills: [],
	characters: [],
	projects: [],
	cssSnippets: [],
	commands: [],
	ui: emptyUi(),
	hydrateUi: () => set((s) => ({ ui: {
		...s.ui,
		hydrated: true
	} })),
	hydrateCollections: (p) => set((s) => ({
		chats: p.chats ?? s.chats,
		mcp: p.mcp ?? s.mcp,
		prompts: p.prompts ?? s.prompts,
		memories: p.memories ?? s.memories,
		skills: p.skills ?? s.skills,
		characters: p.characters ?? s.characters,
		projects: p.projects ?? s.projects,
		cssSnippets: p.cssSnippets ?? s.cssSnippets,
		commands: p.commands ?? s.commands
	})),
	setOnline: (v) => set((s) => ({ ui: {
		...s.ui,
		online: v
	} })),
	setLocale: (locale) => set((s) => ({ settings: {
		...s.settings,
		locale
	} })),
	setTheme: (theme) => set((s) => ({ settings: {
		...s.settings,
		theme
	} })),
	setAccent: (accent) => set((s) => ({ settings: {
		...s.settings,
		accent
	} })),
	patchSettings: (p) => set((s) => ({ settings: {
		...s.settings,
		...p
	} })),
	setAccount: (account) => set({ account }),
	setSidebar: (sidebarOpen) => set((s) => ({ ui: {
		...s.ui,
		sidebarOpen
	} })),
	setAttachOpen: (attachOpen) => set((s) => ({ ui: {
		...s.ui,
		attachOpen
	} })),
	setSettingsOpen: (settingsOpen) => set((s) => ({ ui: {
		...s.ui,
		settingsOpen
	} })),
	setMcpOpen: (mcpOpen) => set((s) => ({ ui: {
		...s.ui,
		mcpOpen
	} })),
	setQueueOpen: (queueOpen) => set((s) => ({ ui: {
		...s.ui,
		queueOpen
	} })),
	setLibraryOpen: (libraryOpen, tab) => set((s) => ({ ui: {
		...s.ui,
		libraryOpen,
		libraryTab: tab ?? s.ui.libraryTab
	} })),
	setCommandsOpen: (commandsOpen) => set((s) => ({ ui: {
		...s.ui,
		commandsOpen
	} })),
	setMode: (mode) => set((s) => ({ ui: {
		...s.ui,
		mode,
		webSearch: mode === "research" ? true : s.ui.webSearch
	} })),
	setWebSearch: (webSearch) => set((s) => ({ ui: {
		...s.ui,
		webSearch
	} })),
	setRagCount: (ragCount) => set((s) => ({ ui: {
		...s.ui,
		ragCount
	} })),
	setArtifact: (artifactId) => set((s) => ({ ui: {
		...s.ui,
		artifactId
	} })),
	setLoginError: (loginError) => set((s) => ({ ui: {
		...s.ui,
		loginError
	} })),
	setLoginBusy: (loginBusy) => set((s) => ({ ui: {
		...s.ui,
		loginBusy
	} })),
	newChat: () => {
		const activeProject = get().projects.find((p) => p.active);
		const chat = {
			id: uid("chat"),
			title: "New chat",
			createdAt: Date.now(),
			updatedAt: Date.now(),
			pinned: false,
			messages: [],
			projectId: activeProject?.id
		};
		set((s) => ({
			chats: [chat, ...s.chats].slice(0, s.settings.maxChatSessions),
			activeChatId: chat.id,
			ui: {
				...s.ui,
				sidebarOpen: false,
				artifactId: null
			}
		}));
		return chat.id;
	},
	selectChat: (id) => set((s) => ({
		activeChatId: id,
		ui: {
			...s.ui,
			sidebarOpen: false,
			artifactId: null
		}
	})),
	renameChat: (id, title) => set((s) => ({ chats: s.chats.map((c) => c.id === id ? {
		...c,
		title
	} : c) })),
	deleteChat: (id) => set((s) => {
		const chats = s.chats.filter((c) => c.id !== id);
		return {
			chats,
			activeChatId: s.activeChatId === id ? chats[0]?.id ?? null : s.activeChatId
		};
	}),
	pinChat: (id) => set((s) => ({ chats: s.chats.map((c) => c.id === id ? {
		...c,
		pinned: !c.pinned
	} : c) })),
	bindDsSession: (chatId, dsSessionId) => set((s) => ({ chats: s.chats.map((c) => c.id === chatId ? {
		...c,
		dsSessionId
	} : c) })),
	appendMessage: (chatId, msg) => set((s) => ({ chats: s.chats.map((c) => c.id === chatId ? {
		...c,
		messages: [...c.messages, msg],
		updatedAt: Date.now()
	} : c) })),
	patchMessage: (chatId, msgId, patch) => set((s) => ({ chats: s.chats.map((c) => c.id !== chatId ? c : {
		...c,
		updatedAt: Date.now(),
		messages: c.messages.map((m) => m.id === msgId ? {
			...m,
			...patch
		} : m)
	}) })),
	setStreaming: (streamingId) => set((s) => ({ ui: {
		...s.ui,
		streamingId
	} })),
	enqueue: (item) => set((s) => ({ queue: [...s.queue, {
		...item,
		id: uid("q"),
		createdAt: Date.now()
	}] })),
	dequeue: (id) => set((s) => ({ queue: s.queue.filter((q) => q.id !== id) })),
	clearQueue: () => set({ queue: [] }),
	toggleMcp: (id) => set((s) => ({ mcp: s.mcp.map((m) => m.id === id ? {
		...m,
		enabled: !m.enabled
	} : m) })),
	setMcpStatus: (id, patch) => set((s) => ({ mcp: s.mcp.map((m) => m.id === id ? {
		...m,
		...patch
	} : m) })),
	upsertMcp: (m) => set((s) => ({ mcp: s.mcp.some((x) => x.id === m.id) ? s.mcp.map((x) => x.id === m.id ? {
		...x,
		...m
	} : x) : [...s.mcp, m] })),
	deleteMcp: (id) => set((s) => ({ mcp: s.mcp.filter((m) => m.id !== id || m.builtin) })),
	upsertPrompt: (p) => set((s) => ({ prompts: s.prompts.some((x) => x.id === p.id) ? s.prompts.map((x) => x.id === p.id ? p : x) : [...s.prompts, p] })),
	deletePrompt: (id) => set((s) => ({ prompts: s.prompts.filter((p) => p.id !== id) })),
	upsertMemory: (m) => set((s) => ({ memories: s.memories.some((x) => x.id === m.id) ? s.memories.map((x) => x.id === m.id ? m : x) : [...s.memories, m] })),
	deleteMemory: (id) => set((s) => ({ memories: s.memories.filter((m) => m.id !== id) })),
	upsertSkill: (sk) => set((s) => ({ skills: s.skills.some((x) => x.id === sk.id) ? s.skills.map((x) => x.id === sk.id ? sk : x) : [...s.skills, sk] })),
	deleteSkill: (id) => set((s) => ({ skills: s.skills.filter((s0) => s0.id !== id) })),
	upsertCharacter: (c) => set((s) => ({ characters: s.characters.some((x) => x.id === c.id) ? s.characters.map((x) => x.id === c.id ? c : {
		...x,
		active: c.active ? false : x.active
	}) : [...s.characters.map((x) => ({
		...x,
		active: c.active ? false : x.active
	})), c] })),
	deleteCharacter: (id) => set((s) => ({ characters: s.characters.filter((c) => c.id !== id) })),
	upsertProject: (p) => set((s) => ({ projects: s.projects.some((x) => x.id === p.id) ? s.projects.map((x) => x.id === p.id ? p : {
		...x,
		active: p.active ? false : x.active
	}) : [...s.projects.map((x) => ({
		...x,
		active: p.active ? false : x.active
	})), p] })),
	deleteProject: (id) => set((s) => ({ projects: s.projects.filter((p) => p.id !== id) })),
	upsertSnippet: (sn) => set((s) => ({ cssSnippets: s.cssSnippets.some((x) => x.id === sn.id) ? s.cssSnippets.map((x) => x.id === sn.id ? sn : x) : [...s.cssSnippets, sn] })),
	deleteSnippet: (id) => set((s) => ({ cssSnippets: s.cssSnippets.filter((x) => x.id !== id) })),
	upsertCommand: (c) => set((s) => ({ commands: s.commands.some((x) => x.id === c.id) ? s.commands.map((x) => x.id === c.id ? c : x) : [...s.commands, c] })),
	deleteCommand: (id) => set((s) => ({ commands: s.commands.filter((c) => c.id !== id) })),
	ensureChat: (prompt) => {
		const s = get();
		const active = s.chats.find((c) => c.id === s.activeChatId);
		if (active && active.messages.length === 0) {
			if (active.title === "New chat") get().renameChat(active.id, titleFromPrompt(prompt));
			return active.id;
		}
		const id = get().newChat();
		get().renameChat(id, titleFromPrompt(prompt));
		return id;
	},
	signOut: () => set({ account: null })
}), {
	name: "super-deepseek-v2",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			...p,
			settings: {
				...defaultSettings,
				...p.settings ?? {}
			},
			ui: current.ui,
			mcp: p.mcp?.length ? p.mcp : current.mcp,
			prompts: p.prompts ?? [],
			memories: p.memories ?? [],
			skills: p.skills ?? [],
			characters: p.characters ?? [],
			projects: p.projects ?? [],
			cssSnippets: p.cssSnippets ?? [],
			commands: p.commands ?? []
		};
	},
	partialize: (s) => ({
		account: s.account,
		chats: s.chats,
		activeChatId: s.activeChatId,
		settings: s.settings,
		mcp: s.mcp.map(({ status: _st, latency: _l, lastPingMs: _p, ...rest }) => ({
			...rest,
			status: "checking"
		})),
		queue: s.queue,
		prompts: s.prompts,
		memories: s.memories,
		skills: s.skills,
		characters: s.characters,
		projects: s.projects,
		cssSnippets: s.cssSnippets,
		commands: s.commands
	})
}));
function useActiveChat() {
	return useAppStore((s) => s.chats.find((c) => c.id === s.activeChatId));
}
function activeArtifact(chat, artifactId) {
	if (!chat || !artifactId) return null;
	for (const m of chat.messages) {
		const hit = m.artifacts?.find((a) => a.id === artifactId);
		if (hit) return hit;
	}
	return null;
}
function emptyMessage(partial) {
	return {
		id: uid("msg"),
		createdAt: Date.now(),
		...partial
	};
}
function composedCss() {
	const s = useAppStore.getState();
	return [s.settings.customCSS, ...s.cssSnippets.filter((x) => x.active).map((x) => x.css)].filter(Boolean).join("\n");
}
var dictionaries = {
	en: {
		appName: "Super DeepSeek",
		tagline: "Frontier reasoning, native feel",
		loginTagline: "Sign in with your DeepSeek account",
		loginHint: "Uses your official DeepSeek credentials. Nothing is stored on our servers — the session lives on this device.",
		loginFailed: "Could not sign in. Check your email or phone and password.",
		signingIn: "Signing in…",
		continueDeepSeek: "Continue with DeepSeek",
		email: "Email",
		phone: "Phone",
		password: "Password",
		signOut: "Sign out",
		newChat: "New chat",
		searchChats: "Search chats",
		today: "Today",
		yesterday: "Yesterday",
		previous7: "Previous 7 days",
		older: "Older",
		pinned: "Pinned",
		emptyTitle: "How can I help you think?",
		emptyBody: "Reasoning, research, code, and live artifacts — in a native-grade workspace.",
		composerPlaceholder: "Message Super DeepSeek",
		send: "Send",
		stop: "Stop",
		attach: "Attach",
		think: "DeepThink",
		search: "Search",
		research: "Research",
		settings: "Settings",
		plugins: "Plugins & Servers",
		library: "Library",
		history: "Chats",
		photos: "Photos",
		photosDesc: "Choose images from the gallery",
		camera: "Camera",
		cameraDesc: "Capture a photo to attach",
		documents: "Documents",
		documentsDesc: "PDF, Office, code, and text up to 50 MB",
		folder: "Index folder",
		folderDesc: "Deep Code — index a project for RAG",
		github: "GitHub repo",
		githubDesc: "Read README and repository context",
		webpage: "Web page",
		webpageDesc: "Extract readable text from a URL",
		commands: "Commands",
		commandsDesc: "Slash shortcuts and saved prompts",
		close: "Close",
		copy: "Copy",
		copied: "Copied",
		run: "Run",
		openArtifact: "Open artifact",
		editArtifact: "Edit",
		preview: "Preview",
		source: "Source",
		thinking: "Thinking",
		thoughtFor: "Thought for {n}s",
		researching: "Deep research",
		queued: "Queued until you are back online",
		offlineTitle: "You're offline",
		offlineBody: "Messages will wait in the queue and send automatically when the connection returns.",
		queueTitle: "Offline queue",
		queueEmpty: "Nothing waiting.",
		retryNow: "Send now",
		clearQueue: "Clear",
		mcpTitle: "Plugins & Servers",
		mcpHint: "One-tap Model Context Protocol presets. Status pings every few seconds.",
		mcpAdd: "Add custom server",
		mcpName: "Name",
		mcpUrl: "Endpoint URL",
		mcpKey: "API key (optional)",
		enabled: "Enabled",
		online: "Online",
		offline: "Offline",
		checking: "Checking",
		appearance: "Appearance",
		theme: "Theme",
		oled: "OLED Black",
		light: "Light",
		system: "System",
		accent: "Accent",
		language: "Language",
		languageRegion: "Language & region",
		chat: "Chat",
		timestamps: "Show timestamps",
		haptics: "Haptic feedback",
		collapse: "Collapse long messages",
		collapseHint: "Hide very long user messages behind a read-more toggle.",
		rag: "Projects & files",
		ragChunks: "Chunks to inject",
		indexedFiles: "Indexed files",
		clearIndex: "Clear index",
		noIndex: "No local files indexed yet.",
		pin: "Pin",
		unpin: "Unpin",
		delete: "Delete",
		rename: "Rename",
		exportChat: "Export",
		suggestions: {
			research: "Research the latest advances in on-device AI",
			code: "Build a small HTML dashboard with live charts",
			explain: "Explain how RAG retrieval actually works",
			prompt: "Draft a coding-mentor system prompt I can reuse"
		},
		codeCopied: "Code copied",
		terminal: "Terminal",
		noChats: "No conversations yet",
		githubPlaceholder: "https://github.com/owner/repo",
		webPlaceholder: "https://example.com/article",
		import: "Import",
		importing: "Importing…",
		cancel: "Cancel",
		save: "Save",
		add: "Add",
		deepCode: "Deep Code",
		deepCodeHint: "Index a local folder for lag-free retrieval.",
		ocrNote: "Text extracted from image",
		compressed: "Compressed",
		shareIncoming: "Shared with Super DeepSeek",
		modelInstant: "Instant",
		done: "Done",
		tryAgain: "Try again",
		aiUnavailable: "The reasoning engine is unavailable right now.",
		splash: "Super DeepSeek",
		prompts: "System prompts",
		memories: "Memories",
		skills: "Skills",
		characters: "Characters",
		projects: "Projects",
		promptInjection: "Prompt & memory",
		deepResearch: "Deep Research",
		integrations: "Integrations",
		utilities: "Utilities",
		customCss: "Custom CSS",
		syncLocale: "Follow device language",
		preferredLang: "Preferred response language",
		preferredLangHint: "Leave empty to let the model decide.",
		preferredLangPlaceholder: "e.g. English, বাংলা, French",
		disableSystemPrompt: "Disable core system prompt",
		disableMemory: "Disable stored memory injection",
		injectDate: "Inject current date and time",
		skipConfirm: "Skip deletion confirmation",
		injectionFreq: "Prompt injection",
		firstMessage: "First message",
		everyMessage: "Every message",
		everyN: "Every N",
		injectionInterval: "Interval (N)",
		tokenPrice: "Token price estimate",
		tokenPriceHint: "Shows a rough DeepSeek API cost under each reply.",
		loadAllHistory: "Load full history on open",
		processGitignore: "Honor .gitignore on folder index",
		projectRag: "Project auto-context (local RAG)",
		autoDownload: "Auto-download created files",
		autoZip: "Auto-download LONG_WORK zip",
		githubToken: "GitHub personal access token",
		githubTokenHint: "Classic token with repo scope, used for private imports.",
		show: "Show",
		hide: "Hide",
		searchProviders: "Search providers",
		searchProvidersHint: "Order used by Deep Research. First successful engine wins.",
		contextGuard: "Context guard",
		contextGuardHint: "Stop Deep Research before the window is exhausted.",
		contextLimit: "Context limit (tokens)",
		stopPercent: "Stop threshold (%)",
		deepFetch: "Deep-fetch top results",
		markdownDepth: "Markdown walker depth",
		sessionCap: "Chat list cap",
		sessionCapHint: "Oldest sessions beyond this cap are dropped from the sidebar.",
		mcpInline: "MCP inline max characters",
		disableTips: "Disable tip box",
		cssPlaceholder: "/* Overrides for this device */",
		cssPresets: "Presets",
		presetCompact: "Compact",
		presetWide: "Wider messages",
		presetCode: "Better code font",
		saveSnippet: "Save as snippet",
		snippetName: "Snippet name",
		exportAll: "Export all data",
		importAll: "Import all data",
		exportEncrypt: "Protect with password",
		enterPassword: "Password",
		confirmPassword: "Confirm password",
		passwordTooShort: "Use at least 4 characters.",
		passwordMismatch: "Passwords do not match.",
		exportDone: "Exported.",
		importDone: "Imported.",
		importFailed: "Import failed.",
		wrongPassword: "Incorrect password.",
		download: "Download",
		selectSections: "Choose sections",
		sectionSettings: "Settings",
		sectionChats: "Chats",
		sectionPrompts: "System prompts",
		sectionMemories: "Memories",
		sectionSkills: "Skills",
		sectionCharacters: "Characters",
		sectionProjects: "Projects",
		sectionMcp: "MCP servers",
		sectionCss: "CSS snippets",
		sectionCommands: "Commands",
		advancedSearch: "Search settings",
		noResults: "No matching settings.",
		name: "Name",
		content: "Content",
		usage: "When to use",
		importance: "Importance",
		always: "Always",
		called: "When relevant",
		active: "Active",
		emptyLibrary: "Nothing saved yet.",
		newPrompt: "New prompt",
		newMemory: "New memory",
		newSkill: "New skill",
		newCharacter: "New character",
		newProject: "New project",
		instructions: "Instructions",
		defaultPrompt: "Default (hidden core)",
		confirmDelete: "Delete this item?",
		discard: "Discard",
		signedInAs: "Signed in",
		account: "Account",
		moveUp: "Move up",
		moveDown: "Move down",
		commandTitle: "Commands & prompts",
		commandHint: "Tap to fill the composer. Saved prompts appear here too.",
		builtinThink: "Switch to DeepThink",
		builtinSearch: "Toggle live web search",
		builtinResearch: "Start Deep Research",
		builtinNew: "Start a new chat",
		key: "Key",
		value: "Value",
		estimatedCost: "Est. {n}",
		guestHint: "You are browsing locally until you sign in.",
		exploreWorkspace: "Explore the workspace",
		signInToSend: "Sign in with DeepSeek to send messages.",
		signInNow: "Sign in",
		guestBanner: "Browsing locally — sign in to talk to DeepSeek."
	},
	bn: {
		appName: "Super DeepSeek",
		tagline: "ফ্রন্টিয়ার রিজনিং, নেটিভ অনুভূতি",
		loginTagline: "আপনার DeepSeek অ্যাকাউন্ট দিয়ে সাইন ইন করুন",
		loginHint: "অফিসিয়াল DeepSeek অ্যাকাউন্ট ব্যবহার হয়। সেশন শুধু এই ডিভাইসে থাকে।",
		loginFailed: "সাইন ইন হয়নি। ইমেইল বা ফোন এবং পাসওয়ার্ড যাচাই করুন।",
		signingIn: "সাইন ইন হচ্ছে…",
		continueDeepSeek: "DeepSeek দিয়ে চালিয়ে যান",
		email: "ইমেইল",
		phone: "ফোন",
		password: "পাসওয়ার্ড",
		signOut: "সাইন আউট",
		newChat: "নতুন চ্যাট",
		searchChats: "চ্যাট খুঁজুন",
		today: "আজ",
		yesterday: "গতকাল",
		previous7: "গত ৭ দিন",
		older: "আরও পুরোনো",
		pinned: "পিন করা",
		emptyTitle: "কী নিয়ে ভাবতে সাহায্য করব?",
		emptyBody: "রিজনিং, রিসার্চ, কোড এবং লাইভ আর্টিফ্যাক্ট — নেটিভ-গ্রেড ওয়ার্কস্পেসে।",
		composerPlaceholder: "Super DeepSeek-কে লিখুন",
		send: "পাঠান",
		stop: "থামান",
		attach: "সংযুক্ত করুন",
		think: "ডিপথিংক",
		search: "সার্চ",
		research: "রিসার্চ",
		settings: "সেটিংস",
		plugins: "প্লাগইন ও সার্ভার",
		library: "লাইব্রেরি",
		history: "চ্যাট",
		photos: "ছবি",
		photosDesc: "গ্যালারি থেকে ছবি বেছে নিন",
		camera: "ক্যামেরা",
		cameraDesc: "ছবি তুলে সংযুক্ত করুন",
		documents: "ডকুমেন্ট",
		documentsDesc: "PDF, অফিস, কোড ও টেক্সট — ৫০ MB পর্যন্ত",
		folder: "ফোল্ডার ইনডেক্স",
		folderDesc: "ডিপ কোড — প্রজেক্ট RAG ইনডেক্স",
		github: "GitHub রিপো",
		githubDesc: "README ও রিপোজিটরি কনটেক্সট পড়ুন",
		webpage: "ওয়েব পেজ",
		webpageDesc: "URL থেকে পাঠযোগ্য লেখা নিন",
		commands: "কমান্ড",
		commandsDesc: "স্ল্যাশ শর্টকাট ও সেভ করা প্রম্পট",
		close: "বন্ধ",
		copy: "কপি",
		copied: "কপি হয়েছে",
		run: "চালান",
		openArtifact: "আর্টিফ্যাক্ট খুলুন",
		editArtifact: "সম্পাদনা",
		preview: "প্রিভিউ",
		source: "সোর্স",
		thinking: "ভাবছে",
		thoughtFor: "{n} সেকেন্ড ধরে ভেবেছে",
		researching: "ডিপ রিসার্চ",
		queued: "অনলাইনে এলে পাঠানো হবে",
		offlineTitle: "আপনি অফলাইনে আছেন",
		offlineBody: "বার্তা কিউতে থাকবে এবং সংযোগ ফিরলে নিজে থেকে পাঠানো হবে।",
		queueTitle: "অফলাইন কিউ",
		queueEmpty: "কিছু অপেক্ষা করছে না।",
		retryNow: "এখনই পাঠান",
		clearQueue: "মুছুন",
		mcpTitle: "প্লাগইন ও সার্ভার",
		mcpHint: "ওয়ান-ট্যাপ MCP প্রিসেট। স্ট্যাটাস কয়েক সেকেন্ডে একবার পিং হয়।",
		mcpAdd: "কাস্টম সার্ভার যোগ করুন",
		mcpName: "নাম",
		mcpUrl: "এন্ডপয়েন্ট URL",
		mcpKey: "API কী (ঐচ্ছিক)",
		enabled: "চালু",
		online: "অনলাইন",
		offline: "অফলাইন",
		checking: "যাচাই হচ্ছে",
		appearance: "চেহারা",
		theme: "থিম",
		oled: "OLED কালো",
		light: "লাইট",
		system: "সিস্টেম",
		accent: "অ্যাকসেন্ট",
		language: "ভাষা",
		languageRegion: "ভাষা ও অঞ্চল",
		chat: "চ্যাট",
		timestamps: "সময় দেখান",
		haptics: "হ্যাপটিক ফিডব্যাক",
		collapse: "লম্বা বার্তা ভাঁজ করুন",
		collapseHint: "খুব লম্বা ইউজার মেসেজ রিড-মোরের আড়ালে রাখুন।",
		rag: "প্রজেক্ট ও ফাইল",
		ragChunks: "ইনজেক্ট করার চাঙ্ক",
		indexedFiles: "ইনডেক্স করা ফাইল",
		clearIndex: "ইনডেক্স মুছুন",
		noIndex: "এখনও কোনো লোকাল ফাইল ইনডেক্স হয়নি।",
		pin: "পিন",
		unpin: "আনপিন",
		delete: "মুছুন",
		rename: "নাম বদলান",
		exportChat: "এক্সপোর্ট",
		suggestions: {
			research: "অন-ডিভাইস AI-এর সর্বশেষ অগ্রগতি নিয়ে রিসার্চ করুন",
			code: "লাইভ চার্টসহ একটি ছোট HTML ড্যাশবোর্ড বানান",
			explain: "RAG রিট্রিভাল আসলে কীভাবে কাজ করে ব্যাখ্যা করুন",
			prompt: "কোডিং-মেন্টর সিস্টেম প্রম্পট খসড়া করুন"
		},
		codeCopied: "কোড কপি হয়েছে",
		terminal: "টার্মিনাল",
		noChats: "এখনও কোনো কথোপকথন নেই",
		githubPlaceholder: "https://github.com/owner/repo",
		webPlaceholder: "https://example.com/article",
		import: "ইমপোর্ট",
		importing: "ইমপোর্ট হচ্ছে…",
		cancel: "বাতিল",
		save: "সেভ",
		add: "যোগ",
		deepCode: "ডিপ কোড",
		deepCodeHint: "তাৎক্ষণিক রিট্রিভালের জন্য একটি লোকাল ফোল্ডার ইনডেক্স করুন।",
		ocrNote: "ছবি থেকে নেওয়া লেখা",
		compressed: "কমপ্রেসড",
		shareIncoming: "Super DeepSeek-এ শেয়ার করা হয়েছে",
		modelInstant: "ইনস্ট্যান্ট",
		done: "সম্পন্ন",
		tryAgain: "আবার চেষ্টা",
		aiUnavailable: "রিজনিং ইঞ্জিন এই মুহূর্তে অনুপলব্ধ।",
		splash: "Super DeepSeek",
		prompts: "সিস্টেম প্রম্পট",
		memories: "মেমরি",
		skills: "স্কিল",
		characters: "ক্যারেক্টার",
		projects: "প্রজেক্ট",
		promptInjection: "প্রম্পট ও মেমরি",
		deepResearch: "ডিপ রিসার্চ",
		integrations: "ইন্টিগ্রেশন",
		utilities: "ইউটিলিটি",
		customCss: "কাস্টম CSS",
		syncLocale: "ডিভাইসের ভাষা অনুসরণ করুন",
		preferredLang: "পছন্দের উত্তরের ভাষা",
		preferredLangHint: "খালি রাখলে মডেল নিজে সিদ্ধান্ত নেবে।",
		preferredLangPlaceholder: "যেমন English, বাংলা, French",
		disableSystemPrompt: "কোর সিস্টেম প্রম্পট বন্ধ",
		disableMemory: "সেভ করা মেমরি ইনজেকশন বন্ধ",
		injectDate: "বর্তমান তারিখ ও সময় ইনজেক্ট",
		skipConfirm: "মুছে ফেলার নিশ্চয়তা এড়িয়ে যান",
		injectionFreq: "প্রম্পট ইনজেকশন",
		firstMessage: "প্রথম বার্তা",
		everyMessage: "প্রতি বার্তা",
		everyN: "প্রতি N",
		injectionInterval: "ইন্টারভাল (N)",
		tokenPrice: "টোকেন খরচের অনুমান",
		tokenPriceHint: "প্রতি উত্তরের নিচে আনুমানিক খরচ দেখায়।",
		loadAllHistory: "খোলার সময় পুরো হিস্টরি লোড",
		processGitignore: "ফোল্ডার ইনডেক্সে .gitignore মানুন",
		projectRag: "প্রজেক্ট অটো-কনটেক্সট (লোকাল RAG)",
		autoDownload: "তৈরি ফাইল অটো-ডাউনলোড",
		autoZip: "LONG_WORK জিপ অটো-ডাউনলোড",
		githubToken: "GitHub পার্সোনাল অ্যাকসেস টোকেন",
		githubTokenHint: "প্রাইভেট ইমপোর্টের জন্য repo স্কোপসহ ক্লাসিক টোকেন।",
		show: "দেখান",
		hide: "লুকান",
		searchProviders: "সার্চ প্রোভাইডার",
		searchProvidersHint: "ডিপ রিসার্চ যে ক্রমে ইঞ্জিন ব্যবহার করবে।",
		contextGuard: "কনটেক্সট গার্ড",
		contextGuardHint: "উইন্ডো শেষ হওয়ার আগে ডিপ রিসার্চ থামান।",
		contextLimit: "কনটেক্সট লিমিট (টোকেন)",
		stopPercent: "থামার থ্রেশহোল্ড (%)",
		deepFetch: "শীর্ষ রেজাল্ট ডিপ-ফেচ",
		markdownDepth: "মার্কডাউন ওয়াকার গভীরতা",
		sessionCap: "চ্যাট তালিকার সীমা",
		sessionCapHint: "এই সীমার বাইরের পুরোনো সেশন সাইডবার থেকে বাদ যায়।",
		mcpInline: "MCP ইনলাইন সর্বোচ্চ অক্ষর",
		disableTips: "টিপ বক্স বন্ধ",
		cssPlaceholder: "/* এই ডিভাইসের ওভাররাইড */",
		cssPresets: "প্রিসেট",
		presetCompact: "কমপ্যাক্ট",
		presetWide: "চওড়া মেসেজ",
		presetCode: "ভালো কোড ফন্ট",
		saveSnippet: "স্নিপেট হিসেবে সেভ",
		snippetName: "স্নিপেটের নাম",
		exportAll: "সব ডেটা এক্সপোর্ট",
		importAll: "সব ডেটা ইমপোর্ট",
		exportEncrypt: "পাসওয়ার্ড দিয়ে সুরক্ষা",
		enterPassword: "পাসওয়ার্ড",
		confirmPassword: "পাসওয়ার্ড নিশ্চিত",
		passwordTooShort: "কমপক্ষে ৪ অক্ষর দিন।",
		passwordMismatch: "পাসওয়ার্ড মিলছে না।",
		exportDone: "এক্সপোর্ট হয়েছে।",
		importDone: "ইমপোর্ট হয়েছে।",
		importFailed: "ইমপোর্ট ব্যর্থ।",
		wrongPassword: "পাসওয়ার্ড ভুল।",
		download: "ডাউনলোড",
		selectSections: "সেকশন বেছে নিন",
		sectionSettings: "সেটিংস",
		sectionChats: "চ্যাট",
		sectionPrompts: "সিস্টেম প্রম্পট",
		sectionMemories: "মেমরি",
		sectionSkills: "স্কিল",
		sectionCharacters: "ক্যারেক্টার",
		sectionProjects: "প্রজেক্ট",
		sectionMcp: "MCP সার্ভার",
		sectionCss: "CSS স্নিপেট",
		sectionCommands: "কমান্ড",
		advancedSearch: "সেটিংস খুঁজুন",
		noResults: "কোনো মিল পাওয়া যায়নি।",
		name: "নাম",
		content: "বিষয়বস্তু",
		usage: "কখন ব্যবহার",
		importance: "গুরুত্ব",
		always: "সবসময়",
		called: "প্রাসঙ্গিক হলে",
		active: "সক্রিয়",
		emptyLibrary: "এখনও কিছু সেভ নেই।",
		newPrompt: "নতুন প্রম্পট",
		newMemory: "নতুন মেমরি",
		newSkill: "নতুন স্কিল",
		newCharacter: "নতুন ক্যারেক্টার",
		newProject: "নতুন প্রজেক্ট",
		instructions: "নির্দেশনা",
		defaultPrompt: "ডিফল্ট (লুকানো কোর)",
		confirmDelete: "এটি মুছে ফেলবেন?",
		discard: "বাতিল",
		signedInAs: "সাইন ইন",
		account: "অ্যাকাউন্ট",
		moveUp: "উপরে",
		moveDown: "নিচে",
		commandTitle: "কমান্ড ও প্রম্পট",
		commandHint: "ট্যাপ করলে কম্পোজারে বসবে। সেভ করা প্রম্পটও এখানে আসে।",
		builtinThink: "ডিপথিংক চালু",
		builtinSearch: "লাইভ ওয়েব সার্চ টগল",
		builtinResearch: "ডিপ রিসার্চ শুরু",
		builtinNew: "নতুন চ্যাট",
		key: "কী",
		value: "মান",
		estimatedCost: "আনুমানিক {n}",
		guestHint: "সাইন ইন না করা পর্যন্ত লোকাল ব্রাউজ করছেন।",
		exploreWorkspace: "ওয়ার্কস্পেস ঘুরে দেখুন",
		signInToSend: "বার্তা পাঠাতে DeepSeek দিয়ে সাইন ইন করুন।",
		signInNow: "সাইন ইন",
		guestBanner: "লোকাল ব্রাউজ করছেন — DeepSeek-এর সাথে কথা বলতে সাইন ইন করুন।"
	}
};
function t(locale, key, vars) {
	const table = dictionaries[locale];
	const parts = key.split(".");
	let cur = table;
	for (const p of parts) if (cur && typeof cur === "object" && p in cur) cur = cur[p];
	else {
		cur = void 0;
		break;
	}
	let s = typeof cur === "string" ? cur : key;
	if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
	return s;
}
var PATTERNS = {
	send: [
		12,
		30,
		18
	],
	success: [
		8,
		40,
		16,
		40,
		24
	],
	error: [
		40,
		40,
		60
	],
	select: 8,
	open: [
		6,
		20,
		10
	]
};
function performHaptic(kind, enabled) {
	if (!enabled || typeof navigator === "undefined") return;
	const vibrate = navigator.vibrate?.bind(navigator);
	if (!vibrate) return;
	try {
		vibrate(PATTERNS[kind]);
	} catch {}
}
var GROUP_LABEL = {
	pinned: "pinned",
	today: "today",
	yesterday: "yesterday",
	week: "previous7",
	older: "older"
};
function SwipeChat({ chat, active, onSelect, onPin, onDelete }) {
	const startX = (0, import_react.useRef)(0);
	const [dx, setDx] = (0, import_react.useState)(0);
	const dragging = (0, import_react.useRef)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-[var(--radius-sm)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 left-0 flex w-20 items-center justify-center bg-accent-dim text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 right-0 flex w-20 items-center justify-center bg-danger/20 text-danger",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: cn("swipe-row relative flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm transition-colors duration-150", active ? "bg-elevated text-fg" : "bg-surface text-muted hover:bg-elevated hover:text-fg"),
				style: { transform: `translateX(${dx}px)` },
				onPointerDown: (e) => {
					dragging.current = true;
					startX.current = e.clientX;
				},
				onPointerMove: (e) => {
					if (!dragging.current) return;
					const next = Math.max(-96, Math.min(96, e.clientX - startX.current));
					setDx(next);
				},
				onPointerUp: () => {
					dragging.current = false;
					if (dx > 56) onPin();
					else if (dx < -56) onDelete();
					setDx(0);
				},
				onPointerCancel: () => {
					dragging.current = false;
					setDx(0);
				},
				onClick: () => {
					if (Math.abs(dx) < 8) onSelect();
				},
				children: [chat.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3 shrink-0 text-accent" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 flex-1 truncate",
					children: chat.title
				})]
			})
		]
	});
}
function Sidebar() {
	const chats = useAppStore((s) => s.chats);
	const active = useAppStore((s) => s.activeChatId);
	const locale = useAppStore((s) => s.settings.locale);
	const haptics = useAppStore((s) => s.settings.haptics);
	const skip = useAppStore((s) => s.settings.skipDeletionConfirmation);
	const queue = useAppStore((s) => s.queue);
	const account = useAppStore((s) => s.account);
	const [q, setQ] = (0, import_react.useState)("");
	const groups = (0, import_react.useMemo)(() => {
		return groupChats(q ? chats.filter((c) => c.title.toLowerCase().includes(q.toLowerCase())) : chats);
	}, [chats, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5 px-4 pb-3 pt-[max(16px,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold tracking-tight",
						children: t(locale, "appName")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[11px] text-muted",
						children: t(locale, "tagline")
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex h-11 w-full items-center justify-center gap-2 rounded-[var(--radius-md)] bg-accent text-sm font-semibold text-accent-fg active:scale-[0.96]",
					onClick: () => {
						performHaptic("open", haptics);
						useAppStore.getState().newChat();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t(locale, "newChat")]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mx-3 mt-3 flex h-10 items-center gap-2 rounded-[var(--radius-sm)] bg-elevated px-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: t(locale, "searchChats"),
					className: "h-full w-full bg-transparent text-sm outline-none placeholder:text-faint"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-3 min-h-0 flex-1 overflow-y-auto overscroll-contain px-2 pb-3",
				children: groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-8 text-center text-sm text-muted",
					children: t(locale, "noChats")
				}) : groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "px-3 pb-1.5 text-[11px] font-medium uppercase tracking-[0.08em] text-faint",
						children: t(locale, GROUP_LABEL[g.key])
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-0.5",
						children: g.items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwipeChat, {
							chat: c,
							active: c.id === active,
							onSelect: () => useAppStore.getState().selectChat(c.id),
							onPin: () => {
								performHaptic("select", haptics);
								useAppStore.getState().pinChat(c.id);
							},
							onDelete: () => {
								if (!skip && !window.confirm(t(locale, "confirmDelete"))) return;
								performHaptic("error", haptics);
								useAppStore.getState().deleteChat(c.id);
							}
						}, c.id))
					})]
				}, g.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 border-t border-line px-2 py-2 pb-[max(10px,env(safe-area-inset-bottom))]",
				children: [
					account ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-wide text-faint",
							children: t(locale, "signedInAs")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm",
							children: account.email || account.mobile
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full items-center gap-3 rounded-[var(--radius-sm)] px-3 text-sm text-muted hover:bg-elevated hover:text-fg",
						onClick: () => useAppStore.getState().setLibraryOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, { className: "size-4" }), t(locale, "library")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full items-center gap-3 rounded-[var(--radius-sm)] px-3 text-sm text-muted hover:bg-elevated hover:text-fg",
						onClick: () => useAppStore.getState().setMcpOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Puzzle, { className: "size-4" }), t(locale, "plugins")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full items-center gap-3 rounded-[var(--radius-sm)] px-3 text-sm text-muted hover:bg-elevated hover:text-fg",
						onClick: () => useAppStore.getState().setSettingsOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), t(locale, "settings")]
					}),
					queue.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full items-center gap-3 rounded-[var(--radius-sm)] px-3 text-sm text-warn hover:bg-elevated",
						onClick: () => useAppStore.getState().setQueueOpen(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "size-4" }),
							t(locale, "queueTitle"),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto tabular-nums text-xs",
								children: queue.length
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full items-center gap-3 rounded-[var(--radius-sm)] px-3 text-sm text-muted hover:bg-elevated hover:text-fg",
						onClick: () => useAppStore.getState().signOut(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), t(locale, "signOut")]
					})
				]
			})
		]
	});
}
var registered = false;
function ensureHljs() {
	if (registered) return;
	registered = true;
	core_default.registerLanguage("javascript", javascript);
	core_default.registerLanguage("js", javascript);
	core_default.registerLanguage("typescript", typescript);
	core_default.registerLanguage("ts", typescript);
	core_default.registerLanguage("tsx", typescript);
	core_default.registerLanguage("jsx", javascript);
	core_default.registerLanguage("python", python);
	core_default.registerLanguage("py", python);
	core_default.registerLanguage("xml", xml);
	core_default.registerLanguage("html", xml);
	core_default.registerLanguage("svg", xml);
	core_default.registerLanguage("css", css);
	core_default.registerLanguage("json", json);
	core_default.registerLanguage("bash", bash);
	core_default.registerLanguage("sh", bash);
	core_default.registerLanguage("shell", bash);
	core_default.registerLanguage("markdown", markdown);
	core_default.registerLanguage("md", markdown);
	core_default.registerLanguage("sql", sql);
	core_default.registerLanguage("rust", rust);
	core_default.registerLanguage("go", go);
	core_default.registerLanguage("java", java);
	core_default.registerLanguage("kotlin", kotlin);
	core_default.registerLanguage("kt", kotlin);
}
function highlight(code, lang) {
	ensureHljs();
	try {
		if (lang && core_default.getLanguage(lang)) return core_default.highlight(code, {
			language: lang,
			ignoreIllegals: true
		}).value;
		return core_default.highlightAuto(code).value;
	} catch {
		return escapeText(code);
	}
}
function escapeText(s) {
	return s.replace(/[&<>"']/g, (ch) => {
		if (ch === "&") return "&amp;";
		if (ch === "<") return "&lt;";
		if (ch === ">") return "&gt;";
		if (ch === "\"") return "&quot;";
		return "&#39;";
	});
}
function CodeBlock({ lang, code, onRun, onOpenArtifact, copyLabel, copiedLabel, runLabel, artifactLabel }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const html = (0, import_react.useMemo)(() => highlight(code, lang), [code, lang]);
	const runnable = lang === "javascript" || lang === "js";
	const isArt = [
		"html",
		"svg",
		"xml",
		"jsx",
		"tsx",
		"css"
	].includes(lang) || code.trim().startsWith("<svg") || code.trim().startsWith("<!DOCTYPE") || code.trim().startsWith("<html");
	async function copy() {
		await navigator.clipboard.writeText(code);
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1400);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "code-block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "code-bar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang || "code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					runnable && onRun ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-7 items-center gap-1 rounded-[var(--radius-xs)] px-2 text-[11px] font-medium uppercase tracking-wide text-fg hover:bg-elevated",
						onClick: () => onRun(code),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3" }), runLabel]
					}) : null,
					isArt && onOpenArtifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-7 items-center rounded-[var(--radius-xs)] px-2 text-[11px] font-medium uppercase tracking-wide text-accent hover:bg-accent-dim",
						onClick: () => onOpenArtifact({
							id: `inline_${lang}`,
							title: lang === "svg" ? "SVG graphic" : "Live preview",
							language: lang || "html",
							code
						}),
						children: artifactLabel
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-7 items-center gap-1 rounded-[var(--radius-xs)] px-2 text-[11px] font-medium uppercase tracking-wide text-fg hover:bg-elevated",
						onClick: () => void copy(),
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" }), copied ? copiedLabel : copyLabel]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "hljs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { dangerouslySetInnerHTML: { __html: html } })
		})]
	});
}
function inlineTokens(tokens) {
	if (!tokens) return null;
	return tokens.map((tok, i) => {
		switch (tok.type) {
			case "strong": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: inlineTokens(tok.tokens) }, i);
			case "em": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: inlineTokens(tok.tokens) }, i);
			case "codespan": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: tok.text }, i);
			case "link": {
				const l = tok;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: l.href,
					target: "_blank",
					rel: "noreferrer",
					children: inlineTokens(l.tokens) ?? l.text
				}, i);
			}
			case "br": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}, i);
			case "text": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tok.text }, i);
			case "escape": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tok.text }, i);
			case "del": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("s", { children: inlineTokens(tok.tokens) }, i);
			default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "text" in tok ? String(tok.text ?? "") : null }, i);
		}
	});
}
function MarkdownView({ markdown, copyLabel = "Copy", copiedLabel = "Copied", runLabel = "Run", artifactLabel = "Open", onRun, onOpenArtifact }) {
	const tokens = (0, import_react.useMemo)(() => gn(markdown || ""), [markdown]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "md-body",
		children: tokens.map((tok, i) => {
			switch (tok.type) {
				case "heading": {
					const h = tok;
					const Tag = `h${Math.min(h.depth, 3)}`;
					const cls = h.depth === 1 ? "text-xl" : h.depth === 2 ? "text-lg" : "text-base";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						className: cn("font-semibold tracking-tight", cls),
						children: inlineTokens(h.tokens)
					}, i);
				}
				case "paragraph": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inlineTokens(tok.tokens) }, i);
				case "list": {
					const list = tok;
					const ListTag = list.ordered ? "ol" : "ul";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTag, {
						className: list.ordered ? "list-decimal" : "list-disc",
						children: list.items.map((item, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inlineTokens(item.tokens) }, j))
					}, i);
				}
				case "code": {
					const c = tok;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
						lang: (c.lang ?? "").split(" ")[0] ?? "",
						code: c.text,
						onRun,
						onOpenArtifact,
						copyLabel,
						copiedLabel,
						runLabel,
						artifactLabel
					}, i);
				}
				case "blockquote": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: inlineTokens(tok.tokens) }, i);
				case "table": {
					const table = tok;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "table-scroll my-3 rounded-[var(--radius-sm)] shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: table.header.map((cell, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: inlineTokens(cell.tokens) }, ci)) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: table.rows.map((row, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: row.map((cell, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: inlineTokens(cell.tokens) }, ci)) }, ri)) })] })
					}, i);
				}
				case "hr": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "border-0 border-t border-line" }, i);
				case "space": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2" }, i);
				case "html": return null;
				default:
					if ("text" in tok && tok.type === "text") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: tok.text }, i);
					return null;
			}
		})
	});
}
function ThinkingBlock({ thinking, steps, thinkingMs, streaming, labels }) {
	const [open, setOpen] = (0, import_react.useState)(streaming);
	if (!thinking && !steps?.length) return null;
	const seconds = Math.max(1, Math.round((thinkingMs ?? 0) / 1e3));
	const title = streaming ? steps?.length ? labels.researching : labels.thinking : labels.thoughtFor.replace("{n}", String(seconds));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 overflow-hidden rounded-[var(--radius-md)] bg-elevated shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			className: "flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atom, { className: cn("size-4 text-accent", streaming && "animate-spin") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1 font-medium text-fg",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 transition-transform duration-200", open && "rotate-180") })
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 border-t border-line px-3 py-3 text-sm text-muted",
			children: [steps?.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1 size-1.5 shrink-0 rounded-full", s.status === "done" && "bg-ok", s.status === "running" && "bg-accent", s.status === "pending" && "bg-faint") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("text-fg", s.status === "running" && "shimmer rounded-sm"),
					children: s.title
				}), s.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs",
					children: s.detail
				}) : null] })]
			}, s.id)), thinking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap text-xs leading-relaxed text-muted",
				children: thinking
			}) : null]
		}) : null]
	});
}
function TerminalCard({ term, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-[var(--radius-md)] bg-code shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 border-b border-line px-3 py-2 text-xs uppercase tracking-wide text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareTerminal, { className: "size-3.5" }),
				label,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-auto font-mono normal-case text-faint",
					children: ["exit ", term.exitCode]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
			className: "max-h-64 overflow-auto p-3 font-mono text-xs leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: ["$ ", term.command.slice(0, 80)]
				}),
				"\n",
				term.stdout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-ok",
					children: term.stdout
				}) : null,
				term.stderr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-danger",
					children: term.stderr
				}) : null,
				!term.stdout && !term.stderr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-faint",
					children: "(no output)"
				}) : null
			]
		})]
	});
}
var FENCE = /```(\w+)[^\n]*\n([\s\S]*?)```/g;
var ARTIFACT_LANGS = /* @__PURE__ */ new Set([
	"html",
	"svg",
	"xml",
	"jsx",
	"tsx",
	"react",
	"vue",
	"css"
]);
function artId() {
	return `art_${Math.random().toString(36).slice(2, 10)}`;
}
function extractArtifacts(markdown) {
	const out = [];
	const re = new RegExp(FENCE.source, "g");
	let m;
	while (m = re.exec(markdown)) {
		const language = (m[1] ?? "txt").toLowerCase();
		const code = (m[2] ?? "").trim();
		if (!code) continue;
		if (!(ARTIFACT_LANGS.has(language) || language === "javascript" && /document\.|createElement|innerHTML/.test(code) || code.startsWith("<svg") || code.startsWith("<!DOCTYPE") || code.startsWith("<html"))) continue;
		if (code.length < 40) continue;
		out.push({
			id: artId(),
			title: language === "svg" ? "SVG graphic" : language === "html" ? "Live preview" : `${language} artifact`,
			language,
			code
		});
	}
	return out.slice(0, 3);
}
function artifactSrcDoc(art) {
	const code = art.code;
	if (art.language === "svg" || code.trim().startsWith("<svg")) return `<!doctype html><html><head><style>html,body{margin:0;background:#0b0b0c;display:grid;place-items:center;min-height:100%}svg{max-width:96%;max-height:96vh}</style></head><body>${code}</body></html>`;
	if (art.language === "css") return `<!doctype html><html><head><style>${code}</style></head><body><div class="preview">Styled preview</div></body></html>`;
	if (/^<!doctype|^<html/i.test(code)) return code;
	return `<!doctype html><html><head><meta charset="utf-8"/><style>html,body{margin:0;padding:16px;font-family:ui-sans-serif,system-ui;background:#0b0b0c;color:#eee}</style></head><body>${code}</body></html>`;
}
var DB = "super-deepseek";
var STORE = "docs";
var SKIP = /(node_modules|\.git|dist|build|\.next|coverage)(\/|$)/i;
var TEXT_EXT = /\.(md|txt|csv|json|ts|tsx|js|jsx|mjs|cjs|py|kt|java|go|rs|css|scss|html|xml|yml|yaml|toml|sql|sh|swift|c|h|cpp|hpp|rb|php|vue|svelte)$/i;
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function ragList() {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
		req.onsuccess = () => resolve(req.result ?? []);
		req.onerror = () => reject(req.error);
	});
}
async function ragPut(doc) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(doc);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
async function ragClear() {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).clear();
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
function shouldIndexFile(path) {
	if (SKIP.test(path)) return false;
	return TEXT_EXT.test(path);
}
async function indexFiles(files) {
	const list = Array.from(files);
	let n = 0;
	for (const file of list) {
		const path = file.webkitRelativePath || file.name;
		if (!shouldIndexFile(path) && !file.type.startsWith("text/")) continue;
		if (file.size > 4e5) continue;
		try {
			const text = await file.text();
			await ragPut({
				id: uid("doc"),
				name: file.name,
				path,
				text: text.slice(0, 8e4),
				addedAt: Date.now()
			});
			n += 1;
		} catch {}
	}
	return n;
}
function score(query, text) {
	const terms = query.toLowerCase().split(/\W+/).filter((t) => t.length > 2);
	if (!terms.length) return 0;
	const hay = text.toLowerCase();
	let s = 0;
	for (const t of terms) {
		let from = 0;
		let hits = 0;
		while (hits < 8) {
			const i = hay.indexOf(t, from);
			if (i < 0) break;
			hits += 1;
			from = i + t.length;
		}
		s += hits;
	}
	return s;
}
async function ragRetrieve(query, k) {
	return (await ragList()).map((d) => ({
		d,
		s: score(query, `${d.path}\n${d.text}`)
	})).filter((x) => x.s > 0).sort((a, b) => b.s - a.s).slice(0, k).map((x) => x.d);
}
function formatRagContext(docs) {
	if (!docs.length) return "";
	return docs.map((d) => `### ${d.path}\n${d.text.slice(0, 1400)}`).join("\n\n");
}
var RESEARCH_STEPS = [
	{
		id: "frame",
		title: "Framing the question"
	},
	{
		id: "search",
		title: "Searching the web"
	},
	{
		id: "read",
		title: "Reading sources"
	},
	{
		id: "check",
		title: "Cross-checking claims"
	},
	{
		id: "write",
		title: "Composing the report"
	}
];
function researchSeed() {
	return RESEARCH_STEPS.map((s, i) => ({
		...s,
		status: i === 0 ? "running" : "pending"
	}));
}
function advanceSteps(steps, chars) {
	const idx = Math.min(steps.length - 1, Math.floor(chars / 180));
	return steps.map((s, i) => ({
		...s,
		status: i < idx ? "done" : i === idx ? "running" : "pending"
	}));
}
function shouldInjectPrompt(userCount) {
	const freq = useAppStore.getState().settings.systemPromptInjectionFrequency;
	const n = useAppStore.getState().settings.systemPromptInjectionInterval || 3;
	if (freq === "always") return true;
	if (freq === "every_n") return userCount % n === 1;
	return userCount <= 1;
}
function composePrompt(userText, attachments, isFirst, userCount) {
	const store = useAppStore.getState();
	const custom = store.prompts.find((p) => p.id === store.settings.activeSystemPromptId);
	const character = store.characters.find((c) => c.active) ?? null;
	const project = store.projects.find((p) => p.active) ?? null;
	const prefix = shouldInjectPrompt(userCount) ? buildSystemPrompt({
		mode: store.ui.mode,
		webSearch: store.ui.webSearch,
		locale: store.settings.locale,
		mcp: store.mcp.filter((m) => m.enabled).map((m) => m.id),
		rag: "",
		preferredLang: store.settings.preferredLang,
		injectDate: store.settings.injectSystemDateTime,
		disableCore: store.settings.disableSystemPrompt,
		customPrompt: custom?.content,
		memories: store.settings.disableMemory ? [] : store.memories,
		skills: store.skills,
		character
	}) : "";
	const files = attachments.map((a) => {
		if (a.text) return `Attached ${a.name}:\n${a.text.slice(0, 12e3)}`;
		if (a.ocrText) return `OCR from ${a.name}:\n${a.ocrText}`;
		return a.kind === "image" ? `[Image attached: ${a.name}]` : `Attached file: ${a.name}`;
	}).filter(Boolean).join("\n\n");
	return [
		prefix,
		isFirst && project?.instructions ? `Active project "${project.name}" instructions:\n${project.instructions}` : "",
		userText,
		files
	].filter(Boolean).join("\n\n");
}
async function sendChat(payload, abort) {
	const store = useAppStore.getState();
	const content = payload.content.trim();
	const attachments = payload.attachments ?? [];
	if (!content && attachments.length === 0) return;
	if (!store.account?.token) {
		const locale = store.settings.locale;
		store.setLoginError(t(locale, "signInToSend"));
		toast.error(t(locale, "signInToSend"));
		return;
	}
	const chatId = payload.chatId ?? store.ensureChat(content || "Attachment");
	const mode = payload.mode ?? store.ui.mode;
	const webSearch = payload.webSearch ?? store.ui.webSearch;
	const userMsg = emptyMessage({
		role: "user",
		content: content || (attachments.length ? "Please review the attached files." : ""),
		attachments
	});
	store.appendMessage(chatId, userMsg);
	if (!store.ui.online) {
		store.enqueue({
			chatId,
			content: userMsg.content,
			attachments,
			mode,
			webSearch
		});
		store.patchMessage(chatId, userMsg.id, { queued: true });
		return;
	}
	const asst = emptyMessage({
		role: "assistant",
		content: "",
		thinking: mode === "think" || mode === "research" ? "" : void 0,
		researchSteps: mode === "research" ? researchSeed() : void 0
	});
	store.appendMessage(chatId, asst);
	store.setStreaming(asst.id);
	performHaptic("send", store.settings.haptics);
	const started = Date.now();
	let rag = "";
	try {
		if (store.settings.projectRagEnabled) rag = formatRagContext(await ragRetrieve(content, store.settings.ragChunks));
	} catch {
		rag = "";
	}
	const chat = useAppStore.getState().chats.find((c) => c.id === chatId);
	const userCount = chat?.messages.filter((m) => m.role === "user").length ?? 1;
	const isFirst = userCount <= 1;
	let prompt = composePrompt(userMsg.content, attachments, isFirst, userCount);
	if (rag) prompt += `\n\n${rag}`;
	if (mode === "research" && store.settings.deepResearchContextGuardEnabled) {
		if (Math.ceil(prompt.length / 4) > store.settings.deepResearchContextLimitTokens * (store.settings.deepResearchContextStopPercent / 100)) {
			store.patchMessage(chatId, asst.id, {
				error: "Deep Research stopped: context guard limit reached.",
				content: ""
			});
			store.setStreaming(null);
			return;
		}
	}
	try {
		const res = await fetch("/api/ds/complete", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${store.account.token}`
			},
			signal: abort?.signal,
			body: JSON.stringify({
				prompt,
				sessionId: chat?.dsSessionId,
				thinking: mode === "think" || mode === "research",
				search: webSearch || mode === "research"
			})
		});
		if (res.status === 401) {
			useAppStore.getState().setAccount(null);
			store.patchMessage(chatId, asst.id, {
				error: "Session expired. Please sign in again.",
				content: ""
			});
			performHaptic("error", store.settings.haptics);
			return;
		}
		if (!res.ok || !res.body) {
			const errText = await res.text().catch(() => "");
			let friendly = "DeepSeek is unavailable right now.";
			try {
				const j = JSON.parse(errText);
				if (j.error) friendly = j.error;
			} catch {}
			store.patchMessage(chatId, asst.id, {
				error: friendly,
				content: ""
			});
			performHaptic("error", store.settings.haptics);
			return;
		}
		const reader = res.body.getReader();
		const decoder = new TextDecoder();
		let buf = "";
		let text = "";
		let thinking = "";
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			buf += decoder.decode(value, { stream: true });
			const chunks = buf.split("\n\n");
			buf = chunks.pop() ?? "";
			for (const chunk of chunks) {
				const line = chunk.split("\n").find((l) => l.startsWith("data:"));
				if (!line) continue;
				const raw = line.slice(5).trim();
				if (!raw || raw === "[DONE]") continue;
				try {
					const ev = JSON.parse(raw);
					if (ev.sessionId) useAppStore.getState().bindDsSession(chatId, ev.sessionId);
					if (ev.type === "error" && ev.error) {
						store.patchMessage(chatId, asst.id, { error: ev.error });
						continue;
					}
					if (typeof ev.thinking === "string") thinking = ev.thinking;
					if (typeof ev.text === "string") text = ev.text;
					const patch = { content: text };
					if (thinking) patch.thinking = thinking;
					if (mode === "research") patch.researchSteps = advanceSteps(asst.researchSteps ?? researchSeed(), text.length);
					store.patchMessage(chatId, asst.id, patch);
				} catch {}
			}
		}
		const artifacts = extractArtifacts(text);
		const steps = (useAppStore.getState().chats.find((c) => c.id === chatId)?.messages.find((m) => m.id === asst.id)?.researchSteps ?? []).map((s) => ({
			...s,
			status: "done"
		}));
		store.patchMessage(chatId, asst.id, {
			content: text,
			thinking: thinking || void 0,
			thinkingMs: Date.now() - started,
			artifacts: artifacts.length ? artifacts : void 0,
			researchSteps: mode === "research" ? steps : void 0
		});
		if (artifacts[0]) store.setArtifact(artifacts[0].id);
		performHaptic("success", store.settings.haptics);
	} catch (err) {
		if (err.name === "AbortError") {
			store.patchMessage(chatId, asst.id, { content: useAppStore.getState().chats.find((c) => c.id === chatId)?.messages.find((m) => m.id === asst.id)?.content || "Stopped." });
			return;
		}
		store.patchMessage(chatId, asst.id, { error: "Could not reach DeepSeek. Your message is safe." });
		performHaptic("error", store.settings.haptics);
	} finally {
		useAppStore.getState().setStreaming(null);
	}
}
function runJsInSandbox(code) {
	const logs = [];
	const errs = [];
	const fake = {
		log: (...a) => logs.push(a.map(String).join(" ")),
		warn: (...a) => logs.push(a.map(String).join(" ")),
		error: (...a) => errs.push(a.map(String).join(" "))
	};
	try {
		new Function("console", `"use strict";\n${code}`)(fake);
		return {
			stdout: logs.join("\n"),
			stderr: errs.join("\n"),
			exitCode: errs.length ? 1 : 0
		};
	} catch (e) {
		return {
			stdout: logs.join("\n"),
			stderr: String(e),
			exitCode: 1
		};
	}
}
function attachTerminal(chatId, command, result) {
	useAppStore.getState().appendMessage(chatId, emptyMessage({
		role: "assistant",
		content: "",
		terminal: {
			id: uid("term"),
			command,
			stdout: result.stdout,
			stderr: result.stderr,
			exitCode: result.exitCode
		}
	}));
}
function estimateCost(text) {
	const tokens = Math.max(1, Math.ceil(text.length / 4));
	const usd = tokens / 1e6 * .28;
	return usd < .01 ? `<$0.01 · ${tokens} tok` : `$${usd.toFixed(3)} · ${tokens} tok`;
}
function Bubble({ msg, streaming }) {
	const locale = useAppStore((s) => s.settings.locale);
	const showTime = useAppStore((s) => s.settings.showTimestamps);
	const collapse = useAppStore((s) => s.settings.collapseLong);
	const price = useAppStore((s) => s.settings.tokenPriceDisplay);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const long = collapse && msg.role === "user" && msg.content.length > 420;
	const body = long && !expanded ? `${msg.content.slice(0, 360)}…` : msg.content;
	if (msg.terminal) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "msg-enter mx-auto w-full max-w-3xl px-4 py-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerminalCard, {
			term: msg.terminal,
			label: t(locale, "terminal")
		})
	});
	const isUser = msg.role === "user";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("msg-enter mx-auto w-full max-w-3xl px-4 py-3", isUser && "flex justify-end"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("min-w-0", isUser ? "max-w-[85%]" : "w-full"),
			children: [isUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] rounded-br-[6px] bg-user px-4 py-3 shadow-[var(--shadow-border)]",
				children: [
					msg.attachments?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 flex flex-wrap gap-2",
						children: msg.attachments.map((a) => a.kind === "image" && a.dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: a.dataUrl,
							alt: a.name,
							className: "h-24 w-24 rounded-[var(--radius-sm)] object-cover"
						}, a.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-[var(--radius-pill)] bg-elevated px-2.5 py-1 text-xs text-muted",
							children: a.name
						}, a.id))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap text-[15px] leading-6",
						children: body
					}),
					long ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-1 text-xs text-accent",
						onClick: () => setExpanded((v) => !v),
						children: expanded ? t(locale, "close") : t(locale, "preview")
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThinkingBlock, {
				thinking: msg.thinking,
				steps: msg.researchSteps,
				thinkingMs: msg.thinkingMs,
				streaming,
				labels: {
					thinking: t(locale, "thinking"),
					thoughtFor: t(locale, "thoughtFor"),
					researching: t(locale, "researching")
				}
			}), msg.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-[var(--radius-md)] bg-danger/10 px-3 py-2 text-sm text-danger",
				children: msg.error
			}) : msg.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, {
				markdown: msg.content,
				copyLabel: t(locale, "copy"),
				copiedLabel: t(locale, "copied"),
				runLabel: t(locale, "run"),
				artifactLabel: t(locale, "openArtifact"),
				onRun: (code) => {
					const chatId = useAppStore.getState().activeChatId;
					if (!chatId) return;
					attachTerminal(chatId, "node sandbox", runJsInSandbox(code));
				},
				onOpenArtifact: (art) => {
					const chatId = useAppStore.getState().activeChatId;
					if (!chatId) return;
					useAppStore.getState().patchMessage(chatId, msg.id, { artifacts: [...(msg.artifacts ?? []).filter((a) => a.id !== art.id), art] });
					useAppStore.getState().setArtifact(art.id);
				}
			}) : streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dot-pulse inline-block align-middle" }),
					" ",
					t(locale, "thinking")
				]
			}) : null] }), showTime || price && !isUser && msg.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("mt-1 text-[11px] text-faint", isUser && "text-right"),
				children: [showTime ? formatTime(msg.createdAt) : null, price && !isUser && msg.content ? `${showTime ? " · " : ""}${t(locale, "estimatedCost", { n: estimateCost(msg.content) })}` : null]
			}) : null]
		})
	});
}
function ChatThread({ messages, streamingId }) {
	const locale = useAppStore((s) => s.settings.locale);
	const bottom = (0, import_react.useRef)(null);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		bottom.current?.scrollIntoView({
			behavior: "smooth",
			block: "end"
		});
	}, [messages, streamingId]);
	if (messages.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 max-w-md text-2xl font-semibold tracking-tight",
				children: t(locale, "emptyTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-md text-sm text-muted",
				children: t(locale, "emptyBody")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid w-full max-w-lg grid-cols-1 gap-2 sm:grid-cols-2",
				children: [
					["suggestions.research", "research"],
					["suggestions.code", "instant"],
					["suggestions.explain", "think"],
					["suggestions.prompt", "prompt"]
				].map(([key, kind]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-[var(--radius-md)] bg-surface px-4 py-3 text-left text-sm text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
					onClick: () => {
						if (kind === "research") useAppStore.getState().setMode("research");
						if (kind === "think") useAppStore.getState().setMode("think");
						const text = t(locale, key);
						window.dispatchEvent(new CustomEvent("sds:fill", { detail: text }));
					},
					children: t(locale, key)
				}, key))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: scroller,
		className: "overscroll-chat min-h-0 flex-1 overflow-y-auto pt-2",
		children: [messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
			msg: m,
			streaming: streamingId === m.id
		}, m.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: bottom,
			className: "h-4"
		})]
	});
}
function ModeChip({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-pill)] px-2.5 text-xs font-medium transition-colors duration-150", active ? "bg-accent-dim text-accent" : "text-muted hover:bg-elevated hover:text-fg"),
		children: [icon, label]
	});
}
function Composer({ value, onChange, attachments, onRemoveAttachment, onSend, onStop }) {
	const locale = useAppStore((s) => s.settings.locale);
	const haptics = useAppStore((s) => s.settings.haptics);
	const mode = useAppStore((s) => s.ui.mode);
	const webSearch = useAppStore((s) => s.ui.webSearch);
	const streaming = useAppStore((s) => s.ui.streamingId);
	const online = useAppStore((s) => s.ui.online);
	const taRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = taRef.current;
		if (!el) return;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
	}, [value]);
	function setMode(next) {
		performHaptic("select", haptics);
		useAppStore.getState().setMode(mode === next ? "instant" : next);
	}
	function onKey(e) {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			if (!streaming) onSend();
		}
	}
	const canSend = Boolean(value.trim() || attachments.length) && !streaming;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 pb-[max(10px,env(safe-area-inset-bottom))] pt-2",
		children: [!online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-center text-xs text-warn",
			children: t(locale, "queued")
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "composer-shell rounded-[var(--radius-xl)] bg-surface p-2",
			children: [
				attachments.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 flex gap-2 overflow-x-auto px-1 pt-1",
					children: attachments.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex h-16 min-w-16 max-w-40 items-center gap-2 rounded-[var(--radius-sm)] bg-elevated pr-8 shadow-[var(--shadow-border)]",
						children: [a.kind === "image" && a.dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: a.dataUrl,
							alt: "",
							className: "h-16 w-16 rounded-[var(--radius-sm)] object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-16 min-w-0 flex-col justify-center px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-xs font-medium",
								children: a.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase text-faint",
								children: a.kind
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(locale, "close"),
							className: "absolute right-1 top-1 flex size-6 items-center justify-center rounded-full bg-bg/80 text-fg",
							onClick: () => onRemoveAttachment(a.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})]
					}, a.id))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					ref: taRef,
					rows: 1,
					value,
					onChange: (e) => onChange(e.target.value),
					onKeyDown: onKey,
					placeholder: t(locale, "composerPlaceholder"),
					className: "max-h-[200px] min-h-11 w-full resize-none bg-transparent px-3 py-2.5 text-[15px] leading-6 outline-none placeholder:text-faint"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(locale, "attach"),
							className: "flex size-10 items-center justify-center rounded-[var(--radius-pill)] text-muted hover:bg-elevated hover:text-fg",
							onClick: () => {
								performHaptic("open", haptics);
								useAppStore.getState().setAttachOpen(true);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeChip, {
									active: mode === "think",
									onClick: () => setMode("think"),
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atom, { className: "size-3.5" }),
									label: t(locale, "think")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeChip, {
									active: webSearch,
									onClick: () => {
										performHaptic("select", haptics);
										useAppStore.getState().setWebSearch(!webSearch);
									},
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3.5" }),
									label: t(locale, "search")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeChip, {
									active: mode === "research",
									onClick: () => setMode("research"),
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Telescope, { className: "size-3.5" }),
									label: t(locale, "research")
								})
							]
						}),
						streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(locale, "stop"),
							className: "flex size-10 items-center justify-center rounded-[var(--radius-pill)] bg-fg text-bg",
							onClick: onStop,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5 fill-current" })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(locale, "send"),
							disabled: !canSend,
							className: "flex size-10 items-center justify-center rounded-[var(--radius-pill)] bg-accent text-accent-fg disabled:opacity-30",
							onClick: onSend,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
						})
					]
				})
			]
		})]
	});
}
function BottomSheet({ open, onOpenChange, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		shouldScaleBackground: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-black/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
			className: cn("fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[88dvh] w-full max-w-lg flex-col", "rounded-t-[var(--radius-xl)] bg-surface text-fg shadow-[var(--shadow-pop)]", "pb-[max(12px,env(safe-area-inset-bottom))]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sheet-handle" }),
				title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "px-5 pb-2 pt-1 text-base font-semibold tracking-tight",
					children: title
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "sr-only",
					children: "Sheet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-2",
					children
				})
			]
		})] })
	});
}
var MAX_EDGE = 1600;
var JPEG_QUALITY = .72;
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("image load failed"));
		img.src = src;
	});
}
/** Client-side stand-in for native Kotlin compression before vision upload. */
async function compressImage(file) {
	const raw = URL.createObjectURL(file);
	try {
		const img = await loadImage(raw);
		const scale = Math.min(1, MAX_EDGE / Math.max(img.width, img.height));
		const width = Math.max(1, Math.round(img.width * scale));
		const height = Math.max(1, Math.round(img.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("no canvas");
		ctx.drawImage(img, 0, 0, width, height);
		const dataUrl = canvas.toDataURL("image/jpeg", JPEG_QUALITY);
		return {
			dataUrl,
			width,
			height,
			bytes: Math.round(dataUrl.length * 3 / 4)
		};
	} finally {
		URL.revokeObjectURL(raw);
	}
}
var TEXT_MAX = 8e4;
var DOC_MAX = 52428800;
var IMG_MAX = 26214400;
async function fileToAttachment(file) {
	const isImg = file.type.startsWith("image/");
	if (isImg && file.size > IMG_MAX) return null;
	if (!isImg && file.size > DOC_MAX) return null;
	if (isImg) {
		const packed = await compressImage(file);
		return {
			id: uid("att"),
			kind: "image",
			name: file.name,
			mime: "image/jpeg",
			size: packed.bytes,
			dataUrl: packed.dataUrl
		};
	}
	let text;
	if (file.type.startsWith("text/") || /\.(md|txt|csv|json|ts|tsx|js|py|kt|html|css|xml|java|go|rs|yml|yaml)$/i.test(file.name)) text = (await file.text()).slice(0, TEXT_MAX);
	return {
		id: uid("att"),
		kind: "file",
		name: file.name,
		mime: file.type || "application/octet-stream",
		size: file.size,
		text
	};
}
function AttachSheet({ onAdd }) {
	const open = useAppStore((s) => s.ui.attachOpen);
	const locale = useAppStore((s) => s.settings.locale);
	const haptics = useAppStore((s) => s.settings.haptics);
	const token = useAppStore((s) => s.settings.githubToken);
	const photoRef = (0, import_react.useRef)(null);
	const camRef = (0, import_react.useRef)(null);
	const docRef = (0, import_react.useRef)(null);
	const folderRef = (0, import_react.useRef)(null);
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const [url, setUrl] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	function close() {
		useAppStore.getState().setAttachOpen(false);
		setDialog(null);
		setUrl("");
		setErr("");
	}
	async function pick(files) {
		if (!files?.length) return;
		performHaptic("select", haptics);
		const items = [];
		for (const f of Array.from(files)) {
			const a = await fileToAttachment(f);
			if (a) items.push(a);
		}
		if (items.length) onAdd(items);
		close();
	}
	async function indexFolder(files) {
		if (!files?.length) return;
		setBusy(true);
		try {
			const n = await indexFiles(files);
			const all = await ragList();
			useAppStore.getState().setRagCount(all.length);
			onAdd([{
				id: uid("att"),
				kind: "folder",
				name: `${n} files indexed`,
				mime: "text/plain",
				size: n,
				text: `Indexed ${n} local files into Deep Code RAG.`
			}]);
			performHaptic("success", haptics);
			close();
		} finally {
			setBusy(false);
		}
	}
	async function importRemote() {
		if (!url.trim()) return;
		setBusy(true);
		setErr("");
		try {
			const data = await (await fetch("/api/import", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					type: dialog,
					url: url.trim(),
					githubToken: token || void 0
				})
			})).json();
			if (!data.ok || !data.text) {
				setErr(data.error || "Import failed");
				performHaptic("error", haptics);
				return;
			}
			onAdd([{
				id: uid("att"),
				kind: "file",
				name: data.title || url,
				mime: "text/plain",
				size: data.text.length,
				text: data.text
			}]);
			performHaptic("success", haptics);
			close();
		} catch {
			setErr("Import failed");
			performHaptic("error", haptics);
		} finally {
			setBusy(false);
		}
	}
	const actions = [
		{
			id: "photos",
			icon: Image$1,
			label: t(locale, "photos"),
			desc: t(locale, "photosDesc"),
			onClick: () => photoRef.current?.click()
		},
		{
			id: "camera",
			icon: Camera,
			label: t(locale, "camera"),
			desc: t(locale, "cameraDesc"),
			onClick: () => camRef.current?.click()
		},
		{
			id: "docs",
			icon: FileText,
			label: t(locale, "documents"),
			desc: t(locale, "documentsDesc"),
			onClick: () => docRef.current?.click()
		},
		{
			id: "folder",
			icon: Folder,
			label: t(locale, "folder"),
			desc: t(locale, "folderDesc"),
			onClick: () => folderRef.current?.click()
		},
		{
			id: "github",
			icon: Github,
			label: t(locale, "github"),
			desc: t(locale, "githubDesc"),
			onClick: () => setDialog("github")
		},
		{
			id: "web",
			icon: Globe,
			label: t(locale, "webpage"),
			desc: t(locale, "webpageDesc"),
			onClick: () => setDialog("web")
		},
		{
			id: "commands",
			icon: Command,
			label: t(locale, "commands"),
			desc: t(locale, "commandsDesc"),
			onClick: () => {
				useAppStore.getState().setCommandsOpen(true);
			}
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange: (v) => v ? useAppStore.getState().setAttachOpen(true) : close(),
		title: t(locale, "attach"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: photoRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				hidden: true,
				onChange: (e) => void pick(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: camRef,
				type: "file",
				accept: "image/*",
				capture: "environment",
				hidden: true,
				onChange: (e) => void pick(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: docRef,
				type: "file",
				multiple: true,
				hidden: true,
				onChange: (e) => void pick(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: folderRef,
				type: "file",
				multiple: true,
				hidden: true,
				className: "hidden",
				onChange: (e) => void indexFolder(e.target.files),
				webkitdirectory: ""
			}),
			dialog ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: url,
						onChange: (e) => setUrl(e.target.value),
						placeholder: t(locale, dialog === "github" ? "githubPlaceholder" : "webPlaceholder"),
						className: "h-11 w-full rounded-[var(--radius-sm)] bg-elevated px-3 text-sm outline-none shadow-[var(--shadow-border)]"
					}),
					err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: err
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 flex-1 rounded-[var(--radius-sm)] bg-elevated text-sm",
							onClick: () => setDialog(null),
							children: t(locale, "cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							className: "h-11 flex-1 rounded-[var(--radius-sm)] bg-accent text-sm font-medium text-accent-fg disabled:opacity-40",
							onClick: () => void importRemote(),
							children: busy ? t(locale, "importing") : t(locale, "import")
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 py-3",
				children: actions.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: a.onClick,
					disabled: busy,
					className: "flex min-h-24 flex-col items-start justify-center gap-1.5 rounded-[var(--radius-md)] bg-elevated px-3 py-3 text-left text-sm text-fg shadow-[var(--shadow-border)] active:scale-[0.98]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(a.icon, { className: "size-5 text-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: a.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] leading-4 text-muted",
							children: a.desc
						})
					]
				}, a.id))
			})
		]
	});
}
function Row({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs leading-5 text-muted",
				children: hint
			}) : null]
		}), children]
	});
}
function Segment({ value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex max-w-full rounded-[var(--radius-sm)] bg-bg p-1 shadow-[var(--shadow-border)]",
		children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(o.id),
			className: cn("h-8 min-w-0 flex-1 rounded-[6px] px-2 text-xs font-medium", value === o.id ? "bg-surface text-fg" : "text-muted"),
			children: o.label
		}, o.id))
	});
}
function Toggle({ on, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick: () => onChange(!on),
		className: cn("relative h-7 w-12 shrink-0 rounded-full transition-colors duration-200", on ? "bg-accent" : "bg-bg shadow-[var(--shadow-border)]"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-200", on ? "translate-x-5" : "translate-x-0.5") })
	});
}
function Card({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4 rounded-[var(--radius-lg)] bg-elevated px-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "pt-3 text-[11px] font-medium uppercase tracking-[0.08em] text-faint",
			children: title
		}), children]
	});
}
function Field({ label, value, onChange, placeholder, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder,
			className: "h-11 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm shadow-[var(--shadow-border)] outline-none placeholder:text-faint"
		})]
	});
}
var SEARCH_PROVIDERS = [
	{
		id: "ddg-lite",
		name: "DuckDuckGo Lite"
	},
	{
		id: "ddg-html",
		name: "DuckDuckGo HTML"
	},
	{
		id: "bing",
		name: "Bing"
	}
];
var BACKUP_SECTIONS = [
	{
		key: "settings",
		labelKey: "sectionSettings"
	},
	{
		key: "chats",
		labelKey: "sectionChats"
	},
	{
		key: "prompts",
		labelKey: "sectionPrompts"
	},
	{
		key: "memories",
		labelKey: "sectionMemories"
	},
	{
		key: "skills",
		labelKey: "sectionSkills"
	},
	{
		key: "characters",
		labelKey: "sectionCharacters"
	},
	{
		key: "projects",
		labelKey: "sectionProjects"
	},
	{
		key: "mcp",
		labelKey: "sectionMcp"
	},
	{
		key: "cssSnippets",
		labelKey: "sectionCss"
	},
	{
		key: "commands",
		labelKey: "sectionCommands"
	}
];
function collectBackup(sections) {
	const s = useAppStore.getState();
	const out = {
		version: 2,
		exportedAt: Date.now()
	};
	if (sections.has("settings")) out.settings = s.settings;
	if (sections.has("chats")) out.chats = s.chats;
	if (sections.has("mcp")) out.mcp = s.mcp.map(({ status, latency, lastPingMs, ...rest }) => rest);
	if (sections.has("prompts")) out.prompts = s.prompts;
	if (sections.has("memories")) out.memories = s.memories;
	if (sections.has("skills")) out.skills = s.skills;
	if (sections.has("characters")) out.characters = s.characters;
	if (sections.has("projects")) out.projects = s.projects;
	if (sections.has("cssSnippets")) out.cssSnippets = s.cssSnippets;
	if (sections.has("commands")) out.commands = s.commands;
	return out;
}
async function deriveKey(password, salt) {
	const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt: salt.buffer,
		iterations: 12e4,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function serializeBackup(payload, password) {
	const json = JSON.stringify(payload);
	if (!password) return json;
	const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const key = await deriveKey(password, salt);
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv: iv.buffer
	}, key, new TextEncoder().encode(json));
	return JSON.stringify({
		enc: "sds-aes-gcm",
		salt: btoa(String.fromCharCode(...salt)),
		iv: btoa(String.fromCharCode(...iv)),
		data: btoa(String.fromCharCode(...new Uint8Array(cipher)))
	});
}
async function parseBackup(raw, password) {
	const parsed = JSON.parse(raw);
	if (parsed.enc === "sds-aes-gcm") {
		if (!password) throw new Error("password");
		const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
		const salt = fromB64(parsed.salt || "");
		const iv = fromB64(parsed.iv || "");
		const data = fromB64(parsed.data || "");
		const key = await deriveKey(password, salt);
		const plain = await crypto.subtle.decrypt({
			name: "AES-GCM",
			iv: iv.buffer
		}, key, data.buffer);
		return JSON.parse(new TextDecoder().decode(plain));
	}
	if (parsed.version !== 2 && !parsed.settings) throw new Error("format");
	return parsed;
}
function applyBackup(payload, sections) {
	const store = useAppStore.getState();
	if (sections.has("settings") && payload.settings) store.patchSettings(payload.settings);
	store.hydrateCollections({
		chats: sections.has("chats") ? payload.chats : void 0,
		mcp: sections.has("mcp") ? payload.mcp : void 0,
		prompts: sections.has("prompts") ? payload.prompts : void 0,
		memories: sections.has("memories") ? payload.memories : void 0,
		skills: sections.has("skills") ? payload.skills : void 0,
		characters: sections.has("characters") ? payload.characters : void 0,
		projects: sections.has("projects") ? payload.projects : void 0,
		cssSnippets: sections.has("cssSnippets") ? payload.cssSnippets : void 0,
		commands: sections.has("commands") ? payload.commands : void 0
	});
}
function SettingsSheet() {
	const open = useAppStore((s) => s.ui.settingsOpen);
	const settings = useAppStore((s) => s.settings);
	const ragCount = useAppStore((s) => s.ui.ragCount);
	const snippets = useAppStore((s) => s.cssSnippets);
	const locale = settings.locale;
	const patch = useAppStore.getState().patchSettings;
	const [q, setQ] = (0, import_react.useState)("");
	const [showToken, setShowToken] = (0, import_react.useState)(false);
	const [exportPw, setExportPw] = (0, import_react.useState)("");
	const [exportPw2, setExportPw2] = (0, import_react.useState)("");
	const [encrypt, setEncrypt] = (0, import_react.useState)(false);
	const [importPw, setImportPw] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)(() => new Set(BACKUP_SECTIONS.map((s) => s.key)));
	const importRef = (0, import_react.useRef)(null);
	const [snippetName, setSnippetName] = (0, import_react.useState)("");
	const hay = q.trim().toLowerCase();
	const show = (keys) => !hay || keys.some((k) => t(locale, k).toLowerCase().includes(hay) || k.includes(hay));
	const cssPresets = (0, import_react.useMemo)(() => [
		{
			id: "compact",
			label: t(locale, "presetCompact"),
			css: ".md-body{font-size:0.9rem} .composer-shell{padding:6px}"
		},
		{
			id: "wide",
			label: t(locale, "presetWide"),
			css: ".md-body{max-width:48rem;margin-inline:auto}"
		},
		{
			id: "code",
			label: t(locale, "presetCode"),
			css: ".hljs,.code-block{font-family:'IBM Plex Mono',ui-monospace,monospace;font-size:13px}"
		}
	], [locale]);
	async function doExport() {
		if (encrypt) {
			if (exportPw.length < 4) {
				toast.error(t(locale, "passwordTooShort"));
				return;
			}
			if (exportPw !== exportPw2) {
				toast.error(t(locale, "passwordMismatch"));
				return;
			}
		}
		const body = await serializeBackup(collectBackup(selected), encrypt ? exportPw : void 0);
		const blob = new Blob([body], { type: "application/json" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `super-deepseek-backup.json`;
		a.click();
		URL.revokeObjectURL(a.href);
		toast.success(t(locale, "exportDone"));
	}
	async function onImportFile(file) {
		if (!file) return;
		try {
			applyBackup(await parseBackup(await file.text(), importPw || void 0), selected);
			toast.success(t(locale, "importDone"));
		} catch (e) {
			const msg = String(e);
			toast.error(msg.includes("password") ? t(locale, "wrongPassword") : t(locale, "importFailed"));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange: (v) => useAppStore.getState().setSettingsOpen(v),
		title: t(locale, "settings"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-4 flex h-11 items-center gap-2 rounded-[var(--radius-sm)] bg-elevated px-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: t(locale, "advancedSearch"),
					className: "h-full w-full bg-transparent text-sm outline-none placeholder:text-faint"
				})]
			}),
			show([
				"appearance",
				"theme",
				"accent"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "appearance"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t(locale, "theme"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: settings.theme,
						onChange: (theme) => patch({ theme }),
						options: [
							{
								id: "oled",
								label: t(locale, "oled")
							},
							{
								id: "light",
								label: t(locale, "light")
							},
							{
								id: "system",
								label: t(locale, "system")
							}
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t(locale, "accent"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: settings.accent,
						onChange: (accent) => patch({ accent }),
						options: [
							{
								id: "ice",
								label: "Ice"
							},
							{
								id: "ocean",
								label: "Ocean"
							},
							{
								id: "sage",
								label: "Sage"
							},
							{
								id: "graphite",
								label: "Ink"
							}
						]
					})
				})]
			}) : null,
			show([
				"language",
				"languageRegion",
				"syncLocale",
				"preferredLang"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "languageRegion"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "language"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							value: settings.locale,
							onChange: (l) => useAppStore.getState().setLocale(l),
							options: [{
								id: "en",
								label: "EN"
							}, {
								id: "bn",
								label: "বাংলা"
							}]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "syncLocale"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.syncLocale,
							onChange: (syncLocale) => patch({ syncLocale })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(locale, "preferredLang"),
						value: settings.preferredLang,
						onChange: (preferredLang) => patch({ preferredLang }),
						placeholder: t(locale, "preferredLangPlaceholder")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "-mt-1 pb-3 text-xs text-muted",
						children: t(locale, "preferredLangHint")
					})
				]
			}) : null,
			show([
				"chat",
				"timestamps",
				"haptics",
				"collapse",
				"sessionCap",
				"tokenPrice"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "chat"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "timestamps"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.showTimestamps,
							onChange: (showTimestamps) => patch({ showTimestamps })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "haptics"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.haptics,
							onChange: (haptics) => patch({ haptics })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "collapse"),
						hint: t(locale, "collapseHint"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.collapseLong,
							onChange: (collapseLong) => patch({ collapseLong })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "skipConfirm"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.skipDeletionConfirmation,
							onChange: (skipDeletionConfirmation) => patch({ skipDeletionConfirmation })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "loadAllHistory"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.loadAllHistoryOnSession,
							onChange: (loadAllHistoryOnSession) => patch({ loadAllHistoryOnSession })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "tokenPrice"),
						hint: t(locale, "tokenPriceHint"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.tokenPriceDisplay,
							onChange: (tokenPriceDisplay) => patch({ tokenPriceDisplay })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "sessionCap"),
						hint: t(locale, "sessionCapHint"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 20,
							max: 2e3,
							value: settings.maxChatSessions,
							onChange: (e) => patch({ maxChatSessions: Number(e.target.value) || 500 }),
							className: "h-9 w-20 rounded-[var(--radius-sm)] bg-bg px-2 text-sm shadow-[var(--shadow-border)]"
						})
					})
				]
			}) : null,
			show([
				"promptInjection",
				"disableSystemPrompt",
				"disableMemory",
				"injectDate"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "promptInjection"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "disableSystemPrompt"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.disableSystemPrompt,
							onChange: (disableSystemPrompt) => patch({ disableSystemPrompt })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "disableMemory"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.disableMemory,
							onChange: (disableMemory) => patch({ disableMemory })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "injectDate"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.injectSystemDateTime,
							onChange: (injectSystemDateTime) => patch({ injectSystemDateTime })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "injectionFreq"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							value: settings.systemPromptInjectionFrequency,
							onChange: (systemPromptInjectionFrequency) => patch({ systemPromptInjectionFrequency }),
							options: [
								{
									id: "first",
									label: t(locale, "firstMessage")
								},
								{
									id: "always",
									label: t(locale, "everyMessage")
								},
								{
									id: "every_n",
									label: t(locale, "everyN")
								}
							]
						})
					}),
					settings.systemPromptInjectionFrequency === "every_n" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "injectionInterval"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 2,
							max: 20,
							value: settings.systemPromptInjectionInterval,
							onChange: (e) => patch({ systemPromptInjectionInterval: Number(e.target.value) || 3 }),
							className: "h-9 w-16 rounded-[var(--radius-sm)] bg-bg px-2 text-sm shadow-[var(--shadow-border)]"
						})
					}) : null
				]
			}) : null,
			show([
				"rag",
				"deepCode",
				"projectRag",
				"processGitignore"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "rag"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "indexedFiles"),
						hint: t(locale, "deepCodeHint"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-sm",
							children: ragCount
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "projectRag"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.projectRagEnabled,
							onChange: (projectRagEnabled) => patch({ projectRagEnabled })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "processGitignore"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.processGitignoreOnUpload,
							onChange: (processGitignoreOnUpload) => patch({ processGitignoreOnUpload })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "ragChunks"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							value: String(settings.ragChunks),
							onChange: (v) => patch({ ragChunks: Number(v) }),
							options: [
								{
									id: "3",
									label: "3"
								},
								{
									id: "5",
									label: "5"
								},
								{
									id: "8",
									label: "8"
								},
								{
									id: "10",
									label: "10"
								}
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-3 h-10 w-full rounded-[var(--radius-sm)] bg-surface text-sm text-danger",
						onClick: () => {
							ragClear().then(() => useAppStore.getState().setRagCount(0));
						},
						children: t(locale, "clearIndex")
					})
				]
			}) : null,
			show([
				"deepResearch",
				"contextGuard",
				"searchProviders"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "deepResearch"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "contextGuard"),
						hint: t(locale, "contextGuardHint"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.deepResearchContextGuardEnabled,
							onChange: (deepResearchContextGuardEnabled) => patch({ deepResearchContextGuardEnabled })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "contextLimit"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 8e3,
							step: 1e3,
							value: settings.deepResearchContextLimitTokens,
							onChange: (e) => patch({ deepResearchContextLimitTokens: Number(e.target.value) || 128e3 }),
							className: "h-9 w-28 rounded-[var(--radius-sm)] bg-bg px-2 text-sm shadow-[var(--shadow-border)]"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "stopPercent"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 50,
							max: 95,
							value: settings.deepResearchContextStopPercent,
							onChange: (e) => patch({ deepResearchContextStopPercent: Number(e.target.value) || 70 }),
							className: "h-9 w-16 rounded-[var(--radius-sm)] bg-bg px-2 text-sm shadow-[var(--shadow-border)]"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "deepFetch"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							value: String(settings.deepResearchDeepFetch),
							onChange: (v) => patch({ deepResearchDeepFetch: Number(v) }),
							options: [
								{
									id: "0",
									label: "0"
								},
								{
									id: "1",
									label: "1"
								},
								{
									id: "3",
									label: "3"
								},
								{
									id: "5",
									label: "5"
								}
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1 text-xs font-medium text-muted",
						children: t(locale, "searchProviders")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-2 text-xs text-faint",
						children: t(locale, "searchProvidersHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1 pb-3",
						children: SEARCH_PROVIDERS.map((p, i) => {
							const on = settings.searchProviders.includes(p.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on,
										onChange: (next) => {
											const cur = settings.searchProviders.filter((id) => id !== p.id);
											patch({ searchProviders: next ? [...cur, p.id] : cur });
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-sm",
										children: p.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-xs text-muted",
										disabled: i === 0,
										onClick: () => {
											const ids = [...settings.searchProviders];
											const idx = ids.indexOf(p.id);
											if (idx > 0) {
												[ids[idx - 1], ids[idx]] = [ids[idx], ids[idx - 1]];
												patch({ searchProviders: ids });
											}
										},
										children: t(locale, "moveUp")
									})
								]
							}, p.id);
						})
					})
				]
			}) : null,
			show(["integrations", "githubToken"]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: t(locale, "integrations"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-xs font-medium text-muted",
							children: t(locale, "githubToken")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: showToken ? "text" : "password",
								value: settings.githubToken,
								onChange: (e) => patch({ githubToken: e.target.value }),
								placeholder: "ghp_…",
								className: "h-11 min-w-0 flex-1 rounded-[var(--radius-sm)] bg-bg px-3 text-sm shadow-[var(--shadow-border)] outline-none"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-[var(--radius-sm)] bg-surface px-3 text-xs",
								onClick: () => setShowToken((v) => !v),
								children: t(locale, showToken ? "hide" : "show")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 pb-2 text-xs text-muted",
							children: t(locale, "githubTokenHint")
						})
					]
				})
			}) : null,
			show([
				"utilities",
				"autoDownload",
				"disableTips"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "utilities"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "autoDownload"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.autoDownloadFiles,
							onChange: (autoDownloadFiles) => patch({ autoDownloadFiles })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "autoZip"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.autoDownloadLongWorkZip,
							onChange: (autoDownloadLongWorkZip) => patch({ autoDownloadLongWorkZip })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "disableTips"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.disableTipBox,
							onChange: (disableTipBox) => patch({ disableTipBox })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-2 text-xs font-medium text-muted",
						children: t(locale, "selectSections")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5 py-2",
						children: BACKUP_SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								const next = new Set(selected);
								if (next.has(s.key)) next.delete(s.key);
								else next.add(s.key);
								setSelected(next);
							},
							className: `h-8 rounded-[var(--radius-pill)] px-2.5 text-xs ${selected.has(s.key) ? "bg-accent-dim text-accent" : "bg-bg text-muted"}`,
							children: t(locale, s.labelKey)
						}, s.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(locale, "exportEncrypt"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: encrypt,
							onChange: setEncrypt
						})
					}),
					encrypt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(locale, "enterPassword"),
						value: exportPw,
						onChange: setExportPw,
						type: "password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(locale, "confirmPassword"),
						value: exportPw2,
						onChange: setExportPw2,
						type: "password"
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-2 h-11 w-full rounded-[var(--radius-sm)] bg-accent text-sm font-medium text-accent-fg",
						onClick: () => void doExport(),
						children: t(locale, "exportAll")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(locale, "enterPassword"),
						value: importPw,
						onChange: setImportPw,
						type: "password",
						placeholder: t(locale, "enterPassword")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: importRef,
						type: "file",
						accept: "application/json,.json",
						hidden: true,
						onChange: (e) => void onImportFile(e.target.files?.[0])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-3 h-11 w-full rounded-[var(--radius-sm)] bg-surface text-sm",
						onClick: () => importRef.current?.click(),
						children: t(locale, "importAll")
					})
				]
			}) : null,
			show(["customCss", "cssPresets"]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: t(locale, "customCss"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1 text-xs text-muted",
						children: t(locale, "cssPresets")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5 py-2",
						children: cssPresets.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-8 rounded-[var(--radius-pill)] bg-bg px-2.5 text-xs",
							onClick: () => patch({ customCSS: `${settings.customCSS}\n${p.css}`.trim() }),
							children: p.label
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: settings.customCSS,
						onChange: (e) => patch({ customCSS: e.target.value }),
						placeholder: t(locale, "cssPlaceholder"),
						rows: 5,
						className: "mb-2 w-full rounded-[var(--radius-sm)] bg-bg p-3 font-mono text-xs leading-5 shadow-[var(--shadow-border)] outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: snippetName,
							onChange: (e) => setSnippetName(e.target.value),
							placeholder: t(locale, "snippetName"),
							className: "h-10 min-w-0 flex-1 rounded-[var(--radius-sm)] bg-bg px-3 text-sm shadow-[var(--shadow-border)]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-[var(--radius-sm)] bg-surface px-3 text-xs",
							onClick: () => {
								if (!snippetName.trim() || !settings.customCSS.trim()) return;
								useAppStore.getState().upsertSnippet({
									id: uid("css"),
									name: snippetName.trim(),
									css: settings.customCSS,
									active: true
								});
								setSnippetName("");
							},
							children: t(locale, "saveSnippet")
						})]
					}),
					snippets.map((sn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: sn.name,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: sn.active,
							onChange: (active) => useAppStore.getState().upsertSnippet({
								...sn,
								active
							})
						})
					}, sn.id))
				]
			}) : null,
			hay && !show([
				"appearance",
				"language",
				"chat",
				"promptInjection",
				"rag",
				"deepResearch",
				"integrations",
				"utilities",
				"customCss"
			]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted",
				children: t(locale, "noResults")
			}) : null
		]
	});
}
function refreshRagCount() {
	ragList().then((d) => useAppStore.getState().setRagCount(d.length));
}
function McpDashboard() {
	const open = useAppStore((s) => s.ui.mcpOpen);
	const mcp = useAppStore((s) => s.mcp);
	const locale = useAppStore((s) => s.settings.locale);
	const [name, setName] = (0, import_react.useState)("");
	const [endpoint, setEndpoint] = (0, import_react.useState)("");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		let alive = true;
		async function tick() {
			const list = useAppStore.getState().mcp;
			await Promise.all(list.map(async (s) => {
				useAppStore.getState().setMcpStatus(s.id, { status: "checking" });
				const r = await pingServer(s);
				if (!alive) return;
				useAppStore.getState().setMcpStatus(s.id, {
					status: r.status,
					latency: r.latency,
					lastPingMs: Date.now()
				});
			}));
		}
		tick();
		const id = window.setInterval(() => void tick(), 14e3);
		return () => {
			alive = false;
			window.clearInterval(id);
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange: (v) => useAppStore.getState().setMcpOpen(v),
		title: t(locale, "mcpTitle"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-3 text-sm text-muted",
				children: t(locale, "mcpHint")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 pb-4",
				children: mcp.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3 rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1.5 size-2 shrink-0 rounded-full", s.status === "online" && "bg-ok", s.status === "offline" && "bg-danger", s.status === "checking" && "bg-warn") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: s.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] uppercase tracking-wide text-faint",
										children: [t(locale, s.status), s.latency != null && s.status === "online" ? ` · ${s.latency}ms` : ""]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: s.description
								}),
								!s.builtin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-1 text-xs text-danger",
									onClick: () => useAppStore.getState().deleteMcp(s.id),
									children: t(locale, "delete")
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: s.enabled,
							onChange: () => useAppStore.getState().toggleMcp(s.id)
						})
					]
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm font-medium",
						children: t(locale, "mcpAdd")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: t(locale, "mcpName"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: endpoint,
						onChange: (e) => setEndpoint(e.target.value),
						placeholder: t(locale, "mcpUrl"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: apiKey,
						onChange: (e) => setApiKey(e.target.value),
						placeholder: t(locale, "mcpKey"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 w-full rounded-[var(--radius-sm)] bg-accent text-sm font-medium text-accent-fg",
						onClick: () => {
							if (!name.trim() || !endpoint.trim()) return;
							useAppStore.getState().upsertMcp({
								id: uid("mcp"),
								name: name.trim(),
								description: endpoint.trim(),
								endpoint: endpoint.trim(),
								enabled: true,
								builtin: false,
								status: "checking",
								apiKey: apiKey.trim() || void 0
							});
							setName("");
							setEndpoint("");
							setApiKey("");
						},
						children: t(locale, "add")
					})
				]
			})
		]
	});
}
function ArtifactsPanel({ artifact, locale, onClose, onChange }) {
	const [tab, setTab] = (0, import_react.useState)("preview");
	const [code, setCode] = (0, import_react.useState)(artifact.code);
	(0, import_react.useEffect)(() => {
		setCode(artifact.code);
		setTab("preview");
	}, [artifact.id, artifact.code]);
	const doc = artifactSrcDoc({
		...artifact,
		code
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col border-l border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 border-b border-line px-3 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1 truncate text-sm font-medium",
					children: artifact.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex rounded-[var(--radius-sm)] bg-elevated p-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-8 rounded-[6px] px-2.5 text-xs font-medium", tab === "preview" ? "bg-surface text-fg" : "text-muted"),
						onClick: () => setTab("preview"),
						children: t(locale, "preview")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-8 rounded-[6px] px-2.5 text-xs font-medium", tab === "source" ? "bg-surface text-fg" : "text-muted"),
						onClick: () => setTab("source"),
						children: t(locale, "source")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": t(locale, "close"),
					className: "flex size-9 items-center justify-center rounded-full text-muted hover:bg-elevated hover:text-fg",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})
			]
		}), tab === "preview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: artifact.title,
			sandbox: "allow-scripts",
			className: "min-h-0 flex-1 bg-bg",
			srcDoc: doc
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: code,
			onChange: (e) => {
				setCode(e.target.value);
				onChange(e.target.value);
			},
			className: "min-h-0 flex-1 resize-none bg-code p-3 font-mono text-xs leading-relaxed outline-none",
			spellCheck: false
		})]
	});
}
function QueueSheet() {
	const open = useAppStore((s) => s.ui.queueOpen);
	const queue = useAppStore((s) => s.queue);
	const locale = useAppStore((s) => s.settings.locale);
	const online = useAppStore((s) => s.ui.online);
	async function flushOne(id) {
		const item = useAppStore.getState().queue.find((q) => q.id === id);
		if (!item) return;
		useAppStore.getState().dequeue(id);
		await sendChat({
			chatId: item.chatId,
			content: item.content,
			attachments: item.attachments,
			mode: item.mode,
			webSearch: item.webSearch
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomSheet, {
		open,
		onOpenChange: (v) => useAppStore.getState().setQueueOpen(v),
		title: t(locale, "queueTitle"),
		children: queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-10 text-center text-sm text-muted",
			children: t(locale, "queueEmpty")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 py-2",
			children: [queue.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-2 text-sm",
					children: q.content
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !online,
						className: "h-9 rounded-[var(--radius-sm)] px-3 text-xs font-medium text-accent disabled:opacity-40",
						onClick: () => void flushOne(q.id),
						children: t(locale, "retryNow")
					})
				})]
			}, q.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-10 w-full rounded-[var(--radius-sm)] text-sm text-danger",
				onClick: () => useAppStore.getState().clearQueue(),
				children: t(locale, "clearQueue")
			})]
		})
	});
}
async function flushQueue() {
	const items = [...useAppStore.getState().queue];
	for (const item of items) {
		useAppStore.getState().dequeue(item.id);
		await sendChat({
			chatId: item.chatId,
			content: item.content,
			attachments: item.attachments,
			mode: item.mode,
			webSearch: item.webSearch
		});
	}
}
var TABS = [
	"prompts",
	"memories",
	"skills",
	"characters",
	"projects"
];
function LibrarySheet() {
	const open = useAppStore((s) => s.ui.libraryOpen);
	const tab = useAppStore((s) => s.ui.libraryTab);
	const locale = useAppStore((s) => s.settings.locale);
	const haptics = useAppStore((s) => s.settings.haptics);
	const skip = useAppStore((s) => s.settings.skipDeletionConfirmation);
	const prompts = useAppStore((s) => s.prompts);
	const memories = useAppStore((s) => s.memories);
	const skills = useAppStore((s) => s.skills);
	const characters = useAppStore((s) => s.characters);
	const projects = useAppStore((s) => s.projects);
	const activePrompt = useAppStore((s) => s.settings.activeSystemPromptId);
	const [name, setName] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [extra, setExtra] = (0, import_react.useState)("");
	function reset() {
		setName("");
		setBody("");
		setExtra("");
	}
	function confirmDel(fn) {
		if (skip || window.confirm(t(locale, "confirmDelete"))) fn();
	}
	function add() {
		const n = name.trim();
		const c = body.trim();
		if (!n || !c) return;
		performHaptic("success", haptics);
		if (tab === "prompts") {
			const id = uid("prm");
			useAppStore.getState().upsertPrompt({
				id,
				name: n,
				content: c
			});
		} else if (tab === "memories") useAppStore.getState().upsertMemory({
			id: uid("mem"),
			key: n,
			value: c,
			importance: extra === "called" ? "called" : "always"
		});
		else if (tab === "skills") useAppStore.getState().upsertSkill({
			id: uid("sk"),
			name: n,
			usage: extra,
			content: c,
			active: true
		});
		else if (tab === "characters") useAppStore.getState().upsertCharacter({
			id: uid("ch"),
			name: n,
			usage: extra,
			content: c,
			active: false
		});
		else useAppStore.getState().upsertProject({
			id: uid("prj"),
			name: n,
			instructions: c,
			active: false
		});
		reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange: (v) => useAppStore.getState().setLibraryOpen(v),
		title: t(locale, "library"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex gap-1 overflow-x-auto rounded-[var(--radius-sm)] bg-elevated p-1",
				children: TABS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useAppStore.getState().setLibraryOpen(true, id),
					className: cn("h-9 shrink-0 rounded-[6px] px-3 text-xs font-medium", tab === id ? "bg-surface text-fg" : "text-muted"),
					children: t(locale, id)
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 pb-4",
				children: [
					tab === "prompts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useAppStore.getState().patchSettings({ activeSystemPromptId: "default" }),
						className: cn("w-full rounded-[var(--radius-md)] bg-elevated px-3 py-3 text-left shadow-[var(--shadow-border)]", activePrompt === "default" && "outline outline-1 outline-accent"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: t(locale, "defaultPrompt")
						})
					}), prompts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						title: p.name,
						body: p.content,
						active: activePrompt === p.id,
						onSelect: () => useAppStore.getState().patchSettings({ activeSystemPromptId: p.id }),
						onDelete: () => confirmDel(() => useAppStore.getState().deletePrompt(p.id))
					}, p.id))] }) : null,
					tab === "memories" ? memories.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						title: m.key,
						body: m.value,
						meta: t(locale, m.importance),
						onDelete: () => confirmDel(() => useAppStore.getState().deleteMemory(m.id))
					}, m.id)) : null,
					tab === "skills" ? skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						title: s.name,
						body: s.content,
						toggle: s.active,
						onToggle: (active) => useAppStore.getState().upsertSkill({
							...s,
							active
						}),
						onDelete: () => confirmDel(() => useAppStore.getState().deleteSkill(s.id))
					}, s.id)) : null,
					tab === "characters" ? characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						title: c.name,
						body: c.content,
						toggle: c.active,
						onToggle: (active) => useAppStore.getState().upsertCharacter({
							...c,
							active
						}),
						onDelete: () => confirmDel(() => useAppStore.getState().deleteCharacter(c.id))
					}, c.id)) : null,
					tab === "projects" ? projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						title: p.name,
						body: p.instructions,
						toggle: p.active,
						onToggle: (active) => useAppStore.getState().upsertProject({
							...p,
							active
						}),
						onDelete: () => confirmDel(() => useAppStore.getState().deleteProject(p.id))
					}, p.id)) : null,
					(tab === "prompts" && prompts.length === 0 || tab === "memories" && memories.length === 0 || tab === "skills" && skills.length === 0 || tab === "characters" && characters.length === 0 || tab === "projects" && projects.length === 0) && tab !== "prompts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-6 text-center text-sm text-muted",
						children: t(locale, "emptyLibrary")
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: tab === "memories" ? t(locale, "key") : t(locale, "name"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}),
					tab === "memories" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegmentMini, {
							value: extra === "called" ? "called" : "always",
							onChange: setExtra,
							a: {
								id: "always",
								label: t(locale, "always")
							},
							b: {
								id: "called",
								label: t(locale, "called")
							}
						})
					}) : tab === "skills" || tab === "characters" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: extra,
						onChange: (e) => setExtra(e.target.value),
						placeholder: t(locale, "usage"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: body,
						onChange: (e) => setBody(e.target.value),
						placeholder: tab === "projects" ? t(locale, "instructions") : t(locale, "content"),
						rows: 3,
						className: "mb-2 w-full rounded-[var(--radius-sm)] bg-bg px-3 py-2 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: add,
						className: "h-11 w-full rounded-[var(--radius-sm)] bg-accent text-sm font-medium text-accent-fg",
						children: t(locale, tab === "prompts" ? "newPrompt" : tab === "memories" ? "newMemory" : tab === "skills" ? "newSkill" : tab === "characters" ? "newCharacter" : "newProject")
					})
				]
			})
		]
	});
}
function SegmentMini({ value, onChange, a, b }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex rounded-[var(--radius-sm)] bg-bg p-1",
		children: [a, b].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(o.id),
			className: cn("h-8 flex-1 rounded-[6px] text-xs font-medium", value === o.id ? "bg-surface text-fg" : "text-muted"),
			children: o.label
		}, o.id))
	});
}
function Item({ title, body, meta, active, toggle, onSelect, onToggle, onDelete }) {
	const locale = useAppStore((s) => s.settings.locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]", active && "outline outline-1 outline-accent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "min-w-0 flex-1 text-left",
				onClick: onSelect,
				disabled: !onSelect,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: title
					}),
					meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-wide text-faint",
						children: meta
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-2 text-xs text-muted",
						children: body
					})
				]
			}), onToggle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: Boolean(toggle),
				onChange: onToggle
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-2 text-xs text-danger",
			onClick: onDelete,
			children: t(locale, "delete")
		})]
	});
}
function fill(text) {
	window.dispatchEvent(new CustomEvent("sds:fill", { detail: text }));
}
function CommandsSheet() {
	const open = useAppStore((s) => s.ui.commandsOpen);
	const locale = useAppStore((s) => s.settings.locale);
	const haptics = useAppStore((s) => s.settings.haptics);
	const prompts = useAppStore((s) => s.prompts);
	const commands = useAppStore((s) => s.commands);
	const [name, setName] = (0, import_react.useState)("");
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const builtins = [
		{
			id: "think",
			icon: Atom,
			label: t(locale, "builtinThink"),
			run: () => useAppStore.getState().setMode("think")
		},
		{
			id: "search",
			icon: Globe,
			label: t(locale, "builtinSearch"),
			run: () => useAppStore.getState().setWebSearch(!useAppStore.getState().ui.webSearch)
		},
		{
			id: "research",
			icon: Telescope,
			label: t(locale, "builtinResearch"),
			run: () => useAppStore.getState().setMode("research")
		},
		{
			id: "new",
			icon: Plus,
			label: t(locale, "builtinNew"),
			run: () => useAppStore.getState().newChat()
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange: (v) => useAppStore.getState().setCommandsOpen(v),
		title: t(locale, "commandTitle"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-3 text-sm text-muted",
				children: t(locale, "commandHint")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 pb-4",
				children: [
					builtins.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-12 w-full items-center gap-3 rounded-[var(--radius-md)] bg-elevated px-3 text-sm shadow-[var(--shadow-border)]",
						onClick: () => {
							performHaptic("select", haptics);
							b.run();
							useAppStore.getState().setCommandsOpen(false);
							useAppStore.getState().setAttachOpen(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(b.icon, { className: "size-4 text-accent" }), b.label]
					}, b.id)),
					prompts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-start gap-3 rounded-[var(--radius-md)] bg-elevated px-3 py-3 text-left text-sm shadow-[var(--shadow-border)]",
						onClick: () => {
							fill(p.content);
							useAppStore.getState().setCommandsOpen(false);
							useAppStore.getState().setAttachOpen(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "mt-0.5 size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "line-clamp-2 text-xs text-muted",
							children: p.content
						})] })]
					}, p.id)),
					commands.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-start gap-3 rounded-[var(--radius-md)] bg-elevated px-3 py-3 text-left text-sm shadow-[var(--shadow-border)]",
						onClick: () => {
							fill(c.prompt);
							useAppStore.getState().setCommandsOpen(false);
							useAppStore.getState().setAttachOpen(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "mt-0.5 size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block font-medium",
								children: ["/", c.name]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "line-clamp-2 text-xs text-muted",
								children: c.prompt
							})]
						})]
					}, c.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: t(locale, "name"),
						className: "mb-2 h-10 w-full rounded-[var(--radius-sm)] bg-bg px-3 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: prompt,
						onChange: (e) => setPrompt(e.target.value),
						placeholder: t(locale, "content"),
						rows: 3,
						className: "mb-2 w-full rounded-[var(--radius-sm)] bg-bg px-3 py-2 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 w-full rounded-[var(--radius-sm)] bg-accent text-sm font-medium text-accent-fg",
						onClick: () => {
							if (!name.trim() || !prompt.trim()) return;
							useAppStore.getState().upsertCommand({
								id: uid("cmd"),
								name: name.trim().replace(/^\//, ""),
								prompt: prompt.trim()
							});
							setName("");
							setPrompt("");
						},
						children: t(locale, "add")
					})
				]
			})
		]
	});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[80] flex flex-col items-center justify-center bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-lg font-semibold tracking-tight",
				children: "Super DeepSeek"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Frontier reasoning, native feel"
			})
		]
	});
}
function LoginScreen() {
	const locale = useAppStore((s) => s.settings.locale);
	const busy = useAppStore((s) => s.ui.loginBusy);
	const error = useAppStore((s) => s.ui.loginError);
	const [tab, setTab] = (0, import_react.useState)("email");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [area, setArea] = (0, import_react.useState)("+880");
	const [password, setPassword] = (0, import_react.useState)("");
	async function onSubmit(e) {
		e.preventDefault();
		const store = useAppStore.getState();
		store.setLoginError("");
		store.setLoginBusy(true);
		try {
			const res = await fetch("/api/ds/login", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(tab === "email" ? {
					email: email.trim(),
					password
				} : {
					mobile: phone.trim(),
					area_code: area,
					password
				})
			});
			const json = await res.json();
			if (!res.ok || !json.token) {
				store.setLoginError(json.error || t(locale, "loginFailed"));
				return;
			}
			store.setAccount({
				token: json.token,
				email: json.email || email.trim(),
				mobile: json.mobile || phone.trim()
			});
		} catch {
			store.setLoginError(t(locale, "loginFailed"));
		} finally {
			store.setLoginBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg px-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end pt-[max(16px,env(safe-area-inset-top))]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex rounded-[var(--radius-sm)] bg-elevated p-1 shadow-[var(--shadow-border)]",
				children: ["en", "bn"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useAppStore.getState().setLocale(id),
					className: cn("h-8 rounded-[6px] px-3 text-xs font-medium", locale === id ? "bg-surface text-fg" : "text-muted"),
					children: id === "en" ? "EN" : "বাংলা"
				}, id))
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-16" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-2xl font-semibold tracking-tight",
							children: t(locale, "appName")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: t(locale, "loginTagline")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-5 flex rounded-[var(--radius-sm)] bg-elevated p-1 shadow-[var(--shadow-border)]",
					children: ["email", "phone"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(id),
						className: cn("h-9 flex-1 rounded-[6px] text-sm font-medium", tab === id ? "bg-surface text-fg" : "text-muted"),
						children: t(locale, id === "email" ? "email" : "phone")
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "space-y-3",
					children: [
						tab === "email" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1.5 block text-xs font-medium text-muted",
								children: t(locale, "email")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								autoComplete: "email",
								required: true,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "you@example.com",
								className: "h-12 w-full rounded-[var(--radius-md)] bg-elevated px-3 text-[15px] shadow-[var(--shadow-border)] outline-none placeholder:text-faint"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1.5 block text-xs font-medium text-muted",
								children: t(locale, "phone")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: area,
									onChange: (e) => setArea(e.target.value),
									className: "h-12 w-20 rounded-[var(--radius-md)] bg-elevated px-3 text-[15px] shadow-[var(--shadow-border)] outline-none"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "tel",
									required: true,
									value: phone,
									onChange: (e) => setPhone(e.target.value),
									placeholder: "1711…",
									className: "h-12 min-w-0 flex-1 rounded-[var(--radius-md)] bg-elevated px-3 text-[15px] shadow-[var(--shadow-border)] outline-none placeholder:text-faint"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1.5 block text-xs font-medium text-muted",
								children: t(locale, "password")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								autoComplete: "current-password",
								required: true,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								className: "h-12 w-full rounded-[var(--radius-md)] bg-elevated px-3 text-[15px] shadow-[var(--shadow-border)] outline-none"
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: busy,
							className: "mt-2 flex h-12 w-full items-center justify-center rounded-[var(--radius-md)] bg-accent text-sm font-semibold text-accent-fg disabled:opacity-50",
							children: busy ? t(locale, "signingIn") : t(locale, "continueDeepSeek")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 flex h-12 w-full items-center justify-center rounded-[var(--radius-md)] bg-elevated text-sm font-medium text-fg shadow-[var(--shadow-border)]",
					onClick: () => {
						useAppStore.getState().setAccount({
							token: "",
							email: "",
							mobile: "",
							guest: true
						});
					},
					children: t(locale, "exploreWorkspace")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-center text-xs leading-5 text-faint",
					children: t(locale, "loginHint")
				})
			]
		})]
	});
}
/** Web equivalent of WindowInsetsAnimationCompat — sync composer with keyboard. */
function bindKeyboardInsets(root) {
	const apply = () => {
		const vv = window.visualViewport;
		if (!vv) {
			root.style.setProperty("--kb", "0px");
			return;
		}
		const kb = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
		root.style.setProperty("--kb", `${Math.round(kb)}px`);
	};
	apply();
	const vv = window.visualViewport;
	vv?.addEventListener("resize", apply);
	vv?.addEventListener("scroll", apply);
	window.addEventListener("resize", apply);
	return () => {
		vv?.removeEventListener("resize", apply);
		vv?.removeEventListener("scroll", apply);
		window.removeEventListener("resize", apply);
	};
}
function resolvedTheme(pref) {
	if (pref === "system") return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "oled";
	return pref;
}
function AppShell() {
	const hydrated = useAppStore((s) => s.ui.hydrated);
	const [splash, setSplash] = (0, import_react.useState)(true);
	const theme = useAppStore((s) => s.settings.theme);
	const accent = useAppStore((s) => s.settings.accent);
	const locale = useAppStore((s) => s.settings.locale);
	const customCSS = useAppStore((s) => s.settings.customCSS);
	const snippets = useAppStore((s) => s.cssSnippets);
	const sidebarOpen = useAppStore((s) => s.ui.sidebarOpen);
	const artifactId = useAppStore((s) => s.ui.artifactId);
	const streamingId = useAppStore((s) => s.ui.streamingId);
	const online = useAppStore((s) => s.ui.online);
	const account = useAppStore((s) => s.account);
	const chat = useActiveChat();
	const haptics = useAppStore((s) => s.settings.haptics);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [atts, setAtts] = (0, import_react.useState)([]);
	const abortRef = (0, import_react.useRef)(null);
	const rootRef = (0, import_react.useRef)(null);
	const [wide, setWide] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useAppStore.persist.rehydrate()).then(() => {
			useAppStore.getState().hydrateUi();
			refreshRagCount();
		});
		const tmr = window.setTimeout(() => setSplash(false), 900);
		return () => window.clearTimeout(tmr);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!rootRef.current) return;
		return bindKeyboardInsets(rootRef.current);
	}, [hydrated]);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			document.documentElement.dataset.theme = resolvedTheme(theme);
			document.documentElement.dataset.accent = accent;
			document.documentElement.style.colorScheme = resolvedTheme(theme) === "light" ? "light" : "dark";
		};
		apply();
		const mq = window.matchMedia("(prefers-color-scheme: light)");
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, [theme, accent]);
	(0, import_react.useEffect)(() => {
		const onResize = () => setWide(window.innerWidth >= 900);
		onResize();
		window.addEventListener("resize", onResize);
		return () => window.removeEventListener("resize", onResize);
	}, []);
	(0, import_react.useEffect)(() => {
		const go = () => {
			useAppStore.getState().setOnline(navigator.onLine);
			if (navigator.onLine) flushQueue();
		};
		go();
		window.addEventListener("online", go);
		window.addEventListener("offline", go);
		return () => {
			window.removeEventListener("online", go);
			window.removeEventListener("offline", go);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onFill = (e) => {
			const text = e.detail;
			setDraft(text);
		};
		window.addEventListener("sds:fill", onFill);
		return () => window.removeEventListener("sds:fill", onFill);
	}, []);
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(window.location.search);
		const shared = params.get("share") || params.get("q") || params.get("text");
		if (shared) {
			setDraft(shared);
			performHaptic("open", haptics);
		}
	}, [haptics]);
	const art = activeArtifact(chat, artifactId);
	const css = composedCss();
	async function onSend() {
		const text = draft;
		const files = atts;
		setDraft("");
		setAtts([]);
		abortRef.current?.abort();
		abortRef.current = new AbortController();
		await sendChat({
			content: text,
			attachments: files,
			chatId: chat?.id
		}, abortRef.current);
	}
	function onStop() {
		abortRef.current?.abort();
		useAppStore.getState().setStreaming(null);
	}
	if (!hydrated || splash) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!account) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	const thread = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 min-w-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 items-center gap-1 px-2 pt-[max(0px,env(safe-area-inset-top))] md:h-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full text-muted hover:bg-elevated hover:text-fg md:hidden",
						"aria-label": "Menu",
						onClick: () => useAppStore.getState().setSidebar(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 flex-1 truncate px-2 text-sm font-medium",
						children: chat?.title ?? t(locale, "newChat")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full text-muted hover:bg-elevated hover:text-fg",
						"aria-label": t(locale, "newChat"),
						onClick: () => {
							performHaptic("open", haptics);
							useAppStore.getState().newChat();
							setDraft("");
							setAtts([]);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
					})
				]
			}),
			!online ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mb-1 rounded-[var(--radius-sm)] bg-warn/15 px-3 py-2 text-center text-xs text-warn",
				children: [
					t(locale, "offlineTitle"),
					" — ",
					t(locale, "offlineBody")
				]
			}) : null,
			account?.guest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mb-1 flex items-center justify-between gap-2 rounded-[var(--radius-sm)] bg-accent-dim px-3 py-2 text-xs text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "guestBanner") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "shrink-0 font-semibold",
					onClick: () => useAppStore.getState().setAccount(null),
					children: t(locale, "signInNow")
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatThread, {
				messages: chat?.messages ?? [],
				streamingId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
				value: draft,
				onChange: setDraft,
				attachments: atts,
				onRemoveAttachment: (id) => setAtts((xs) => xs.filter((a) => a.id !== id)),
				onSend: () => void onSend(),
				onStop
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		className: "app-root",
		children: [
			css ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: css }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: resolvedTheme(theme) === "light" ? "light" : "dark",
				position: "top-center",
				toastOptions: { className: "font-sans" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-72 shrink-0 border-r border-line md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("fixed inset-0 z-40 md:hidden", sidebarOpen ? "pointer-events-auto" : "pointer-events-none"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("absolute inset-0 bg-black/50 transition-opacity duration-200", sidebarOpen ? "opacity-100" : "opacity-0"),
					"aria-label": t(locale, "close"),
					onClick: () => useAppStore.getState().setSidebar(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("absolute inset-y-0 left-0 w-[min(20rem,88vw)] bg-surface shadow-[var(--shadow-pop)] transition-transform duration-300", sidebarOpen ? "translate-x-0" : "-translate-x-full"),
					style: { transitionTimingFunction: "cubic-bezier(0.22, 1, 0.36, 1)" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex min-w-0 flex-1",
				children: art && wide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(qt, {
					orientation: "horizontal",
					className: "h-full w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qt, {
							defaultSize: 56,
							minSize: 36,
							children: thread
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(nn, { className: "w-px bg-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qt, {
							defaultSize: 44,
							minSize: 28,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactsPanel, {
								artifact: art,
								locale,
								onClose: () => useAppStore.getState().setArtifact(null),
								onChange: (code) => {
									if (!chat) return;
									for (const m of chat.messages) {
										if (!m.artifacts) continue;
										if (m.artifacts.some((a) => a.id === art.id)) useAppStore.getState().patchMessage(chat.id, m.id, { artifacts: m.artifacts.map((a) => a.id === art.id ? {
											...a,
											code
										} : a) });
									}
								}
							})
						})
					]
				}) : thread
			}),
			art && !wide ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactsPanel, {
					artifact: art,
					locale,
					onClose: () => useAppStore.getState().setArtifact(null),
					onChange: () => {}
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachSheet, { onAdd: (items) => setAtts((xs) => [...xs, ...items]) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(McpDashboard, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibrarySheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandsSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "sr-only",
				children: [customCSS, snippets.length]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
